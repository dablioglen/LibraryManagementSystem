/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Student_Dashboard;
import Admin_dashboard.logout_confirmation;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import com.formdev.flatlaf.FlatLightLaf;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableRowSorter;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.Timer;

/**
 *
 * @author dabli
 */
public class student_dashboard extends javax.swing.JFrame {
    Color panelcolor = new Color(182,196,182);
    Color defcolor = new Color(109,139,116);
    public static String getstudent_no;
    public static String getStudNo;
    /**
     * Creates new form student_dashboard
     */
    
    public student_dashboard() {
        initComponents();
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        displayBooksInTable();
        filterTableField();
        displayCartBooks();
        displayBookRequested();
        displayBookBorrowers();
        displayAnnouncement();
        times();
        dt();
        
        book_category_filter.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    
                    books_pub_filter.setSelectedIndex(-1);
                    book_available_filter.setSelectedIndex(-1);
                    search_books_field.setText("");

                    
                    String selectedCategory = (String) book_category_filter.getSelectedItem();
                    displayBooksByCategory(selectedCategory);
                }
            }
        });
        books_pub_filter.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    
                    book_category_filter.setSelectedIndex(-1);
                    book_available_filter.setSelectedIndex(-1);
                    search_books_field.setText("");

                   
                    String selectedPubYear = (String) books_pub_filter.getSelectedItem();
                    displayBooksPubYear(selectedPubYear);
                }
            }
        });
        book_available_filter.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    // Clear items of other JComboBox components
                    
                    book_category_filter.setSelectedIndex(-1);
                    books_pub_filter.setSelectedIndex(-1);
                    search_books_field.setText("");
                    

                    String book_availble = (String) book_available_filter.getSelectedItem();
                    displayBooksAvailable(book_availble);
                }
            }
        });
        
        library_books_brs.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 1) {
                    // Get the selected row and column
                    int selectedRow = library_books_brs.getSelectedRow();
                    
                    // Ensure a valid row is selected
                    if (selectedRow != -1) {
                        // Get the data from the selected row
                        String accNo = (String) library_books_brs.getValueAt(selectedRow, 0);
                        String bookTitle = (String) library_books_brs.getValueAt(selectedRow, 1);
                        String bookAuthor = (String) library_books_brs.getValueAt(selectedRow, 2);
                        String bookCategory = (String) library_books_brs.getValueAt(selectedRow, 3);
                        String publicationYear = (String) library_books_brs.getValueAt(selectedRow, 6);
                        String bookDescription = (String) library_books_brs.getValueAt(selectedRow, 7);
                        ImageIcon bookImageIcon = (ImageIcon) library_books_brs.getValueAt(selectedRow, 8);
                        
                        // Open the new frame with the selected data
                       openNewFrame( accNo, bookTitle, bookAuthor, bookCategory, publicationYear, bookDescription, bookImageIcon);
                    }
                }
            }
        });
        book_cart_data.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 1) {
                    // Get the selected row and column
                    int selectedRow = book_cart_data.getSelectedRow();
                    
                    // Ensure a valid row is selected
                    if (selectedRow != -1) {
                        // Get the data from the selected row
                        String studNum = (String) book_cart_data.getValueAt(selectedRow, 0);
                        String accNo = (String) book_cart_data.getValueAt(selectedRow, 1);
                        String bookTitle = (String) book_cart_data.getValueAt(selectedRow, 2);
                        
                        
                        // Open the new frame with the selected data
                       openFrameRequest(studNum, accNo, bookTitle);
                    }
                }
            }
        });
        
       
        
         
    }
     Timer t ;
     SimpleDateFormat st ;
    public void times(){

   
    
  t = new Timer(0, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        Date dt  =new Date();
        st = new SimpleDateFormat("hh:mm:ss");
        
        String tt = st.format(dt);
        clock_feature.setText(tt);
        clock_feature.setHorizontalAlignment(SwingConstants.CENTER);
        
        }
    });
  
    t.start();
    
    

}
    public void dt(){

    Date d  =new Date();
    
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MMM-dd");
    
    String dd = sdf.format(d);
    home_date.setText(dd);
    home_date.setHorizontalAlignment(SwingConstants.CENTER);


}
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        home_bt = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        account_bt = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        library_books_bt = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        my_books_bt = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        logout_student_bt = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        student_home_p = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jPanel13 = new RoundedPanel(20);
        jLabel31 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        lib_announcement = new javax.swing.JTextArea();
        admin_name_welcome = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jPanel11 = new RoundedPanel(20);
        clock_feature = new javax.swing.JLabel();
        home_date = new javax.swing.JLabel();
        student_acc_p = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        student_image_d = new javax.swing.JLabel();
        student_no_d = new javax.swing.JLabel();
        jPanel9 = new RoundedPanel(25,Color.WHITE);
        jLabel17 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        studName_lb = new javax.swing.JTextField();
        studSex_lb = new javax.swing.JTextField();
        studAge_lb = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        studAddress_lb = new javax.swing.JTextArea();
        studEmail_lb = new javax.swing.JTextField();
        studTel_lb = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        studCourse_lb = new javax.swing.JTextArea();
        studYear_lb = new javax.swing.JTextField();
        studSection_lb = new javax.swing.JTextField();
        jPanel10 = new RoundedPanel(25,Color.WHITE);
        jLabel18 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        stud_issuedDate_lb = new javax.swing.JLabel();
        studStatus_lb = new javax.swing.JLabel();
        library_books_p = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        search_books_field = new javax.swing.JTextField();
        search_book_bt = new javax.swing.JButton();
        book_category_filter = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        books_pub_filter = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        book_available_filter = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        library_books_brs = new javax.swing.JTable();
        student_myBooks_p = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        book_cart_bt = new RoundedPanel(20);
        jLabel28 = new javax.swing.JLabel();
        requested_book_bt = new RoundedPanel(20);
        jLabel29 = new javax.swing.JLabel();
        accepted_book_bt = new RoundedPanel(20);
        jLabel30 = new javax.swing.JLabel();
        user_books_container = new javax.swing.JPanel();
        user_cart_panel = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        book_cart_data = new javax.swing.JTable();
        book_request_panel = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        requested_book_data = new javax.swing.JTable();
        accepted_books = new javax.swing.JPanel();
        jScrollPane10 = new javax.swing.JScrollPane();
        book_borrowers_data = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(109, 139, 116));

        jPanel3.setBackground(new java.awt.Color(85, 96, 82));
        jPanel3.setPreferredSize(new java.awt.Dimension(200, 140));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/udm-seal_70px.png"))); // NOI18N

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText(" STUDENT DASHBOARD");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(66, 66, 66)
                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 71, Short.MAX_VALUE)
                .addGap(64, 64, 64))
            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE)
                .addGap(12, 12, 12))
        );

        home_bt.setBackground(new java.awt.Color(182, 196, 182));
        home_bt.setPreferredSize(new java.awt.Dimension(100, 54));
        home_bt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                home_btMouseClicked(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/home.png"))); // NOI18N
        jLabel1.setText("Home");

        javax.swing.GroupLayout home_btLayout = new javax.swing.GroupLayout(home_bt);
        home_bt.setLayout(home_btLayout);
        home_btLayout.setHorizontalGroup(
            home_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(home_btLayout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(69, 69, 69))
        );
        home_btLayout.setVerticalGroup(
            home_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
        );

        account_bt.setBackground(new java.awt.Color(109, 139, 116));
        account_bt.setPreferredSize(new java.awt.Dimension(0, 54));
        account_bt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                account_btMouseClicked(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/user.png"))); // NOI18N
        jLabel2.setText("Account");

        javax.swing.GroupLayout account_btLayout = new javax.swing.GroupLayout(account_bt);
        account_bt.setLayout(account_btLayout);
        account_btLayout.setHorizontalGroup(
            account_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(account_btLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(59, 59, 59))
        );
        account_btLayout.setVerticalGroup(
            account_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
        );

        library_books_bt.setBackground(new java.awt.Color(109, 139, 116));
        library_books_bt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                library_books_btMouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/books.png"))); // NOI18N
        jLabel3.setText("Books");

        javax.swing.GroupLayout library_books_btLayout = new javax.swing.GroupLayout(library_books_bt);
        library_books_bt.setLayout(library_books_btLayout);
        library_books_btLayout.setHorizontalGroup(
            library_books_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(library_books_btLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(72, 72, 72))
        );
        library_books_btLayout.setVerticalGroup(
            library_books_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
        );

        my_books_bt.setBackground(new java.awt.Color(109, 139, 116));
        my_books_bt.setPreferredSize(new java.awt.Dimension(0, 54));
        my_books_bt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                my_books_btMouseClicked(evt);
            }
        });

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/user_book.png"))); // NOI18N
        jLabel4.setText("My Books");

        javax.swing.GroupLayout my_books_btLayout = new javax.swing.GroupLayout(my_books_bt);
        my_books_bt.setLayout(my_books_btLayout);
        my_books_btLayout.setHorizontalGroup(
            my_books_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, my_books_btLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(52, 52, 52))
        );
        my_books_btLayout.setVerticalGroup(
            my_books_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
        );

        jPanel8.setBackground(new java.awt.Color(109, 139, 116));
        jPanel8.setPreferredSize(new java.awt.Dimension(10, 54));

        logout_student_bt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/logout.png"))); // NOI18N
        logout_student_bt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logout_student_btMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(logout_student_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logout_student_bt, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
            .addComponent(home_bt, javax.swing.GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
            .addComponent(account_bt, javax.swing.GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
            .addComponent(library_books_bt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(my_books_bt, javax.swing.GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(home_bt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(account_bt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(library_books_bt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(my_books_bt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(272, 272, 272)
                .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.LINE_START);

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setLayout(new java.awt.CardLayout());

        student_home_p.setBackground(new java.awt.Color(182, 196, 182));

        jPanel5.setBackground(new java.awt.Color(115, 144, 114));
        jPanel5.setPreferredSize(new java.awt.Dimension(100, 50));

        jLabel14.setText("HOME");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel14)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        jLabel31.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel31.setText("                        LIBRARY ANNOUNCEMENT");

        lib_announcement.setEditable(false);
        lib_announcement.setColumns(20);
        lib_announcement.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lib_announcement.setLineWrap(true);
        lib_announcement.setRows(5);
        lib_announcement.setWrapStyleWord(true);
        jScrollPane8.setViewportView(lib_announcement);

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jScrollPane8)
                .addGap(35, 35, 35))
            .addComponent(jLabel31, javax.swing.GroupLayout.DEFAULT_SIZE, 447, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel31)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        admin_name_welcome.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        admin_name_welcome.setText("STUDENT");

        jLabel32.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel32.setText("GOOD DAY STUDENT");

        clock_feature.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        clock_feature.setText("12:30");

        home_date.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        home_date.setText("jLabel5");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(clock_feature, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
            .addComponent(home_date, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addComponent(clock_feature, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(home_date)
                .addContainerGap(27, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout student_home_pLayout = new javax.swing.GroupLayout(student_home_p);
        student_home_p.setLayout(student_home_pLayout);
        student_home_pLayout.setHorizontalGroup(
            student_home_pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, 992, Short.MAX_VALUE)
            .addGroup(student_home_pLayout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addGroup(student_home_pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(student_home_pLayout.createSequentialGroup()
                        .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(student_home_pLayout.createSequentialGroup()
                        .addComponent(jLabel32)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(admin_name_welcome)))
                .addContainerGap(224, Short.MAX_VALUE))
        );
        student_home_pLayout.setVerticalGroup(
            student_home_pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(student_home_pLayout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addGroup(student_home_pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(admin_name_welcome))
                .addGap(38, 38, 38)
                .addGroup(student_home_pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(152, Short.MAX_VALUE))
        );

        jPanel2.add(student_home_p, "card2");

        student_acc_p.setBackground(new java.awt.Color(182, 196, 182));

        jPanel6.setBackground(new java.awt.Color(115, 144, 114));
        jPanel6.setPreferredSize(new java.awt.Dimension(100, 50));

        jLabel15.setText("ACCOUNT");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel15)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        student_image_d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        student_no_d.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        student_no_d.setText("STUDENT NO");
        student_no_d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel17.setText("                                           STUDENT INFORMATION");

        jLabel19.setText("NAME:");

        jLabel20.setText("SEX:");

        jLabel21.setText("AGE:");

        jLabel22.setText("ADDRESS:");

        jLabel23.setText("EMAIL:");

        jLabel24.setText("TEL NO:");

        jLabel25.setText("COURSE:");

        jLabel26.setText("YEAR:");

        jLabel27.setText("SECTION:");

        studName_lb.setEditable(false);

        studSex_lb.setEditable(false);

        studAge_lb.setEditable(false);

        studAddress_lb.setEditable(false);
        studAddress_lb.setColumns(20);
        studAddress_lb.setLineWrap(true);
        studAddress_lb.setRows(5);
        studAddress_lb.setWrapStyleWord(true);
        jScrollPane4.setViewportView(studAddress_lb);

        studEmail_lb.setEditable(false);

        studTel_lb.setEditable(false);

        studCourse_lb.setEditable(false);
        studCourse_lb.setColumns(20);
        studCourse_lb.setLineWrap(true);
        studCourse_lb.setRows(5);
        studCourse_lb.setWrapStyleWord(true);
        jScrollPane5.setViewportView(studCourse_lb);

        studYear_lb.setEditable(false);

        studSection_lb.setEditable(false);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(studName_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel20)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(studSex_lb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(studAge_lb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel9Layout.createSequentialGroup()
                                .addComponent(jLabel25)
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel23))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(studEmail_lb)
                                    .addComponent(jScrollPane4))))
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel24)
                                    .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(studTel_lb, javax.swing.GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE)
                                    .addComponent(studYear_lb)))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel27)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(studSection_lb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap())))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel17)
                .addGap(24, 24, 24)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(studName_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(studSex_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20)
                    .addComponent(studAge_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel21)
                    .addComponent(jLabel19))
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(jLabel22))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel24)
                            .addComponent(studTel_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(studEmail_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel23)
                    .addComponent(jLabel26)
                    .addComponent(studYear_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jLabel25))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel27)
                            .addComponent(studSection_lb, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jLabel18.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel18.setText("                     STUDENT STATUS");

        jLabel37.setText("ISSUED DATE:");

        jLabel38.setText("STATUS:");

        stud_issuedDate_lb.setText("[]");

        studStatus_lb.setText("[]");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel38)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(studStatus_lb))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel37)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(stud_issuedDate_lb)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel18)
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel37)
                    .addComponent(stud_issuedDate_lb))
                .addGap(28, 28, 28)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel38)
                    .addComponent(studStatus_lb))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout student_acc_pLayout = new javax.swing.GroupLayout(student_acc_p);
        student_acc_p.setLayout(student_acc_pLayout);
        student_acc_pLayout.setHorizontalGroup(
            student_acc_pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, 992, Short.MAX_VALUE)
            .addGroup(student_acc_pLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(student_acc_pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(student_image_d, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(student_no_d, javax.swing.GroupLayout.DEFAULT_SIZE, 96, Short.MAX_VALUE))
                .addGap(27, 27, 27)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        student_acc_pLayout.setVerticalGroup(
            student_acc_pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(student_acc_pLayout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(student_acc_pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(student_acc_pLayout.createSequentialGroup()
                        .addComponent(student_image_d, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(student_no_d, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 375, Short.MAX_VALUE))
        );

        jPanel2.add(student_acc_p, "card3");

        library_books_p.setBackground(new java.awt.Color(182, 196, 182));

        jPanel7.setBackground(new java.awt.Color(115, 144, 114));
        jPanel7.setPreferredSize(new java.awt.Dimension(100, 50));

        jLabel16.setText("LIBRARY BOOKS");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel16)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setText("BROWSE BOOKS");

        search_book_bt.setText("Search");
        search_book_bt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                search_book_btMouseClicked(evt);
            }
        });

        book_category_filter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "Business", "Education", "Environment", "Information and Publishing", "Law", "Literature", "Medicine", "Nation and World", "Religion", "Science", "Social Science", "Technology", "Engineering", "Mathematics" }));
        book_category_filter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                book_category_filterActionPerformed(evt);
            }
        });

        jLabel10.setText("Category");

        jLabel11.setText("Pub. Year");

        books_pub_filter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "2024", "2023", "2022", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995" }));
        books_pub_filter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                books_pub_filterActionPerformed(evt);
            }
        });

        jLabel12.setText("Book Available");

        book_available_filter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "0", "1" }));
        book_available_filter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                book_available_filterActionPerformed(evt);
            }
        });

        library_books_brs.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ACC NO.", "TITLE", "AUTHOR", "CATEGORY", "BOOK AVAILABLE", "BOOK BORROW", "PUBLICATION YEAR", "DESCRIPTION", "IMAGE"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(library_books_brs);

        javax.swing.GroupLayout library_books_pLayout = new javax.swing.GroupLayout(library_books_p);
        library_books_p.setLayout(library_books_pLayout);
        library_books_pLayout.setHorizontalGroup(
            library_books_pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, 992, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, library_books_pLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(library_books_pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, library_books_pLayout.createSequentialGroup()
                        .addComponent(search_books_field, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(search_book_bt)
                        .addGap(18, 246, Short.MAX_VALUE)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(book_category_filter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(books_pub_filter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(book_available_filter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, library_books_pLayout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1))
                .addGap(26, 26, 26))
        );
        library_books_pLayout.setVerticalGroup(
            library_books_pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(library_books_pLayout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(library_books_pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(library_books_pLayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(book_category_filter, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(search_book_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(library_books_pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel10)
                        .addComponent(jLabel11)
                        .addComponent(books_pub_filter, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel12)
                        .addComponent(book_available_filter, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(search_books_field, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 577, Short.MAX_VALUE)
                .addGap(15, 15, 15))
        );

        jPanel2.add(library_books_p, "card4");

        student_myBooks_p.setBackground(new java.awt.Color(182, 196, 182));

        jPanel4.setBackground(new java.awt.Color(115, 144, 114));
        jPanel4.setPreferredSize(new java.awt.Dimension(100, 50));

        jLabel13.setText("USERS BOOKS");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        book_cart_bt.setPreferredSize(new java.awt.Dimension(142, 32));
        book_cart_bt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                book_cart_btMouseClicked(evt);
            }
        });

        jLabel28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/shopping-cart.png"))); // NOI18N
        jLabel28.setText("Book Cart");

        javax.swing.GroupLayout book_cart_btLayout = new javax.swing.GroupLayout(book_cart_bt);
        book_cart_bt.setLayout(book_cart_btLayout);
        book_cart_btLayout.setHorizontalGroup(
            book_cart_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(book_cart_btLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );
        book_cart_btLayout.setVerticalGroup(
            book_cart_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel28, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
        );

        requested_book_bt.setBackground(new java.awt.Color(109, 139, 116));
        requested_book_bt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                requested_book_btMouseClicked(evt);
            }
        });

        jLabel29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/requested_book.png"))); // NOI18N
        jLabel29.setText("Requested Books");

        javax.swing.GroupLayout requested_book_btLayout = new javax.swing.GroupLayout(requested_book_bt);
        requested_book_bt.setLayout(requested_book_btLayout);
        requested_book_btLayout.setHorizontalGroup(
            requested_book_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(requested_book_btLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel29)
                .addContainerGap(18, Short.MAX_VALUE))
        );
        requested_book_btLayout.setVerticalGroup(
            requested_book_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel29, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        accepted_book_bt.setBackground(new java.awt.Color(109, 139, 116));
        accepted_book_bt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                accepted_book_btMouseClicked(evt);
            }
        });

        jLabel30.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/accepted_books.png"))); // NOI18N
        jLabel30.setText("Accepted Books");

        javax.swing.GroupLayout accepted_book_btLayout = new javax.swing.GroupLayout(accepted_book_bt);
        accepted_book_bt.setLayout(accepted_book_btLayout);
        accepted_book_btLayout.setHorizontalGroup(
            accepted_book_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(accepted_book_btLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel30)
                .addContainerGap(16, Short.MAX_VALUE))
        );
        accepted_book_btLayout.setVerticalGroup(
            accepted_book_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        user_books_container.setLayout(new java.awt.CardLayout());

        user_cart_panel.setBackground(new java.awt.Color(153, 153, 153));

        book_cart_data.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STUDENT NO.", "ACC NO.", "TITLE", "AUTHOR", "CATEGORY", "BOOK AVAILABLE", "PUBLICATION YEAR", "DATE ADDED"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(book_cart_data);

        javax.swing.GroupLayout user_cart_panelLayout = new javax.swing.GroupLayout(user_cart_panel);
        user_cart_panel.setLayout(user_cart_panelLayout);
        user_cart_panelLayout.setHorizontalGroup(
            user_cart_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 939, Short.MAX_VALUE)
        );
        user_cart_panelLayout.setVerticalGroup(
            user_cart_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 602, Short.MAX_VALUE)
        );

        user_books_container.add(user_cart_panel, "card2");

        book_request_panel.setBackground(new java.awt.Color(182, 196, 182));

        requested_book_data.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STUDENT NO.", "ACC NO.", "TITLE", "AUTHOR", "CATEGORY", "BOOK AVAILABLE", "PUBLICATION YEAR", "DATE ADDED"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(requested_book_data);

        javax.swing.GroupLayout book_request_panelLayout = new javax.swing.GroupLayout(book_request_panel);
        book_request_panel.setLayout(book_request_panelLayout);
        book_request_panelLayout.setHorizontalGroup(
            book_request_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 939, Short.MAX_VALUE)
        );
        book_request_panelLayout.setVerticalGroup(
            book_request_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 602, Short.MAX_VALUE)
        );

        user_books_container.add(book_request_panel, "card3");

        accepted_books.setBackground(new java.awt.Color(255, 102, 102));

        book_borrowers_data.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STUDENT ID", "ACC NO.", "TITLE", "AUTHOR", "CATEGORY", "PUBLICATION YEAR", "DATE ACCEPTED", "RETURN DUE DATE", "BOOK FEE PENALTY"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane10.setViewportView(book_borrowers_data);

        javax.swing.GroupLayout accepted_booksLayout = new javax.swing.GroupLayout(accepted_books);
        accepted_books.setLayout(accepted_booksLayout);
        accepted_booksLayout.setHorizontalGroup(
            accepted_booksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 939, Short.MAX_VALUE)
            .addGroup(accepted_booksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 939, Short.MAX_VALUE))
        );
        accepted_booksLayout.setVerticalGroup(
            accepted_booksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 602, Short.MAX_VALUE)
            .addGroup(accepted_booksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 602, Short.MAX_VALUE))
        );

        user_books_container.add(accepted_books, "card4");

        javax.swing.GroupLayout student_myBooks_pLayout = new javax.swing.GroupLayout(student_myBooks_p);
        student_myBooks_p.setLayout(student_myBooks_pLayout);
        student_myBooks_pLayout.setHorizontalGroup(
            student_myBooks_pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, 992, Short.MAX_VALUE)
            .addGroup(student_myBooks_pLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(student_myBooks_pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(user_books_container, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(student_myBooks_pLayout.createSequentialGroup()
                        .addComponent(book_cart_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(requested_book_bt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(accepted_book_bt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(47, 47, 47))
        );
        student_myBooks_pLayout.setVerticalGroup(
            student_myBooks_pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(student_myBooks_pLayout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(student_myBooks_pLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(book_cart_bt, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
                    .addComponent(requested_book_bt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(accepted_book_bt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(user_books_container, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(30, 30, 30))
        );

        jPanel2.add(student_myBooks_p, "card5");

        getContentPane().add(jPanel2, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    public void setStudentDetails(Object[] studentDetails) throws SQLException {
        
    String studID = (String) studentDetails[0];
    String firstName = (String) studentDetails[1];
    String lastName = (String) studentDetails[2];
    
    String studEmail = (String) studentDetails[3];
    String studSex = (String) studentDetails[4];
    String stud_tel = (String) studentDetails[5];
    String studCourse = (String) studentDetails[6];
    String studYear = (String) studentDetails[7];
    String studSection = (String) studentDetails[8];
    String studAddress = (String) studentDetails[9];
    
    Date   studIssuedDate = (Date) studentDetails[10];
    byte[] studImageBytes = (byte[]) studentDetails[11];
    String studAge = (String) studentDetails[12];
    int studStatus = (int) studentDetails[13];
    
    
    
    
    
    
    //String admin_issued_by = (String) adminDetails[8];
    

    // Set the first name and last name labels
    studName_lb.setText((firstName + " " + lastName).toUpperCase());
    admin_name_welcome.setText((firstName + " " + lastName+"!").toUpperCase());
    // Convert the byte array to ImageIcon and set it in adminImage label
    ImageIcon adminImageIcon = createImageIcon(studImageBytes);
    student_image_d.setIcon(adminImageIcon);
    
    student_no_d.setText(studID);
    student_no_d.setHorizontalAlignment(SwingConstants.CENTER);
    studSex_lb.setText((studSex).toUpperCase());
    studAge_lb.setText(studAge);
    studTel_lb.setText(stud_tel);
    studAddress_lb.setText(studAddress.toUpperCase());

    studEmail_lb.setText(studEmail);
    studCourse_lb.setText(studCourse.toUpperCase());

    studYear_lb.setText((studYear).toUpperCase());
    studSection_lb.setText((studSection).toUpperCase());
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    stud_issuedDate_lb.setText(dateFormat.format(studIssuedDate));
    String statusText = (studStatus == 1) ? "Active" : "Inactive";
    studStatus_lb.setText(statusText);
    
    getstudent_no = student_no_d.getText();
    getStudNo = studID;
    
    
}
    
  private void openNewFrame(String accNo, String bookTitle, String bookAuthor, String bookCategory, String publicationYear, String bookDescription, ImageIcon bookImageIcon) {
    // Create an instance of your popup_book_details frame
    popup_book_details newFrame = new popup_book_details();
    
    // Set the book details in the new frame
    newFrame.setBookDetails(accNo, bookTitle, bookAuthor, bookCategory, publicationYear, bookDescription, bookImageIcon);
    newFrame.setStudentNumber(getstudent_no);
    
    // Set properties and make the frame visible
    
    newFrame.setLocationRelativeTo(null);
    newFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    newFrame.setVisible(true);
}
  private void openFrameRequest(String studNum, String accNo, String bookTitle) {
    // Create an instance of your popup_book_details frame
    popup_book_request frame_request = new popup_book_request();
    
    // Set the book details in the new frame
    frame_request.setBookRequestD(studNum, accNo, bookTitle);
    frame_request.setVisible(true);
    
    // Set properties and make the frame visible
    
   
   
}
  private ImageIcon createImageIcon(byte[] imageData) {
    try {
        // Convert byte array to BufferedImage
        ByteArrayInputStream bis = new ByteArrayInputStream(imageData);
        BufferedImage bImage = ImageIO.read(bis);

        // Resize the image as needed (optional)
        Image resizedImage = bImage.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
     
        // Convert BufferedImage to ImageIcon
        return new ImageIcon(resizedImage);
    } catch (IOException e) {
        e.printStackTrace();
        return null;
    }
}  
    
  


        

    
  
    private void home_btMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_home_btMouseClicked
        // TODO add your handling code here:
        student_home_p.setVisible(true);
        student_acc_p.setVisible(false);
        library_books_p.setVisible(false);
        student_myBooks_p.setVisible(false);
        
        home_bt.setBackground(panelcolor);
        account_bt.setBackground(defcolor);
        library_books_bt.setBackground(defcolor);
        my_books_bt.setBackground(defcolor);
        
    }//GEN-LAST:event_home_btMouseClicked

    private void account_btMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_account_btMouseClicked
        // TODO add your handling code here:
        student_home_p.setVisible(false);
        student_acc_p.setVisible(true);
        library_books_p.setVisible(false);
        student_myBooks_p.setVisible(false);
        
        home_bt.setBackground(defcolor);
        account_bt.setBackground(panelcolor);
        library_books_bt.setBackground(defcolor);
        my_books_bt.setBackground(defcolor);
    }//GEN-LAST:event_account_btMouseClicked

    private void library_books_btMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_library_books_btMouseClicked
        // TODO add your handling code here:
        student_home_p.setVisible(false);
        student_acc_p.setVisible(false);
        library_books_p.setVisible(true);
        student_myBooks_p.setVisible(false);
        
        home_bt.setBackground(defcolor);
        account_bt.setBackground(defcolor);
        library_books_bt.setBackground(panelcolor);
        my_books_bt.setBackground(defcolor);
    }//GEN-LAST:event_library_books_btMouseClicked

    private void my_books_btMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_my_books_btMouseClicked
        // TODO add your handling code here:
        displayCartBooks();
        student_home_p.setVisible(false);
        student_acc_p.setVisible(false);
        library_books_p.setVisible(false);
        student_myBooks_p.setVisible(true);
        
        home_bt.setBackground(defcolor);
        account_bt.setBackground(defcolor);
        library_books_bt.setBackground(defcolor);
        my_books_bt.setBackground(panelcolor);
    }//GEN-LAST:event_my_books_btMouseClicked

    private void search_book_btMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_search_book_btMouseClicked
        // TODO add your handling code here:
        book_category_filter.setSelectedIndex(-1);
        books_pub_filter.setSelectedIndex(-1);
        book_available_filter.setSelectedIndex(-1);
        filterTableField();
        
    }//GEN-LAST:event_search_book_btMouseClicked

    private void book_category_filterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_book_category_filterActionPerformed
        
        //String selectedCategory = (String) book_category_filter.getSelectedItem();
        //displayBooksByCategory(selectedCategory);
        
    }//GEN-LAST:event_book_category_filterActionPerformed

    private void books_pub_filterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_books_pub_filterActionPerformed
        // TODO add your handling code here:
        
        
    }//GEN-LAST:event_books_pub_filterActionPerformed

    private void book_available_filterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_book_available_filterActionPerformed
        // TODO add your handling code here:
        
        
        
    }//GEN-LAST:event_book_available_filterActionPerformed

    private void book_cart_btMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_book_cart_btMouseClicked
        // TODO add your handling code here:
        
        user_cart_panel.setVisible(true);
        book_request_panel.setVisible(false);
        accepted_books.setVisible(false);
        
        book_cart_bt.setBackground(Color.WHITE);
        requested_book_bt.setBackground(defcolor);
        accepted_book_bt.setBackground(defcolor);
    }//GEN-LAST:event_book_cart_btMouseClicked

    private void requested_book_btMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_requested_book_btMouseClicked
        // TODO add your handling code here:
        displayBookRequested();
        user_cart_panel.setVisible(false);
        book_request_panel.setVisible(true);
        accepted_books.setVisible(false);
        
        book_cart_bt.setBackground(defcolor);
        requested_book_bt.setBackground(Color.WHITE);
        accepted_book_bt.setBackground(defcolor);
        
    }//GEN-LAST:event_requested_book_btMouseClicked

    private void accepted_book_btMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_accepted_book_btMouseClicked
        // TODO add your handling code here:
        displayBookBorrowers();
        user_cart_panel.setVisible(false);
        book_request_panel.setVisible(false);
        accepted_books.setVisible(true);
        
        book_cart_bt.setBackground(defcolor);
        requested_book_bt.setBackground(defcolor);
        accepted_book_bt.setBackground(Color.WHITE);
    }//GEN-LAST:event_accepted_book_btMouseClicked

    private void logout_student_btMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logout_student_btMouseClicked
        // TODO add your handling code here:
        student_logout logout_c = new student_logout(this);
        logout_c.setVisible(true);
        logout_c.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }//GEN-LAST:event_logout_student_btMouseClicked
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        FlatLightLaf.setup();
       
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        /*try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(student_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(student_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(student_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(student_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        */
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new student_dashboard().setVisible(true);
            }
        });
         
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel accepted_book_bt;
    private javax.swing.JPanel accepted_books;
    private javax.swing.JPanel account_bt;
    private javax.swing.JLabel admin_name_welcome;
    private static javax.swing.JComboBox<String> book_available_filter;
    private static javax.swing.JTable book_borrowers_data;
    private javax.swing.JPanel book_cart_bt;
    private static javax.swing.JTable book_cart_data;
    public static javax.swing.JComboBox<String> book_category_filter;
    private javax.swing.JPanel book_request_panel;
    private static javax.swing.JComboBox<String> books_pub_filter;
    private javax.swing.JLabel clock_feature;
    private javax.swing.JPanel home_bt;
    private javax.swing.JLabel home_date;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane8;
    private static javax.swing.JTextArea lib_announcement;
    private static javax.swing.JTable library_books_brs;
    private javax.swing.JPanel library_books_bt;
    private javax.swing.JPanel library_books_p;
    private javax.swing.JLabel logout_student_bt;
    private javax.swing.JPanel my_books_bt;
    private javax.swing.JPanel requested_book_bt;
    private static javax.swing.JTable requested_book_data;
    private javax.swing.JButton search_book_bt;
    public static javax.swing.JTextField search_books_field;
    private javax.swing.JTextArea studAddress_lb;
    private javax.swing.JTextField studAge_lb;
    private javax.swing.JTextArea studCourse_lb;
    private javax.swing.JTextField studEmail_lb;
    private javax.swing.JTextField studName_lb;
    private javax.swing.JTextField studSection_lb;
    private javax.swing.JTextField studSex_lb;
    private javax.swing.JLabel studStatus_lb;
    private javax.swing.JTextField studTel_lb;
    private javax.swing.JTextField studYear_lb;
    private javax.swing.JLabel stud_issuedDate_lb;
    private javax.swing.JPanel student_acc_p;
    private javax.swing.JPanel student_home_p;
    private javax.swing.JLabel student_image_d;
    private javax.swing.JPanel student_myBooks_p;
    private javax.swing.JLabel student_no_d;
    private javax.swing.JPanel user_books_container;
    private javax.swing.JPanel user_cart_panel;
    // End of variables declaration//GEN-END:variables
class RoundedPanel extends JPanel
    {
        //private static Color panelcolor = new Color(109, 139, 116);
        private Color backgroundColor;
        private int cornerRadius = 15;
        public RoundedPanel(LayoutManager layout, int radius) {
            super(layout);
            cornerRadius = radius;
            setOpaque(false);
        }
        public RoundedPanel(LayoutManager layout, int radius, Color bgColor) {
            super(layout);
            cornerRadius = radius;
            backgroundColor = bgColor;
            setOpaque(false);
        }
        public RoundedPanel(int radius) {
            super();
            cornerRadius = radius;
            setOpaque(false);
            
        }
        public RoundedPanel(int radius, Color bgColor) {
            super();
            cornerRadius = radius;
            backgroundColor = bgColor;
            setOpaque(false);
        }
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Dimension arcs = new Dimension(cornerRadius, cornerRadius);
            int width = getWidth();
            int height = getHeight();
            Graphics2D graphics = (Graphics2D) g;
            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            //Draws the rounded panel with borders.
            if (backgroundColor != null) {
                graphics.setColor(backgroundColor);
            } else {
                graphics.setColor(getBackground());
            }
            graphics.fillRoundRect(0, 0, width-1, height-1, arcs.width, arcs.height); //paint background
            graphics.setColor(getForeground());
//            graphics.drawRoundRect(0, 0, width-1, height-1, arcs.width, arcs.height); //paint border
//             
        }
    }
public static void displayBooksInTable() {
        DefaultTableModel model = (DefaultTableModel) library_books_brs.getModel();
        model.setRowCount(0); // Clear existing rows from the table
        
        // Set up cell renderer for center alignment
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
    
    // Apply the renderer to all columns in the table
        int columnCount = library_books_brs.getColumnCount();
        for (int i = 0; i < columnCount; i++) {
        library_books_brs.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
         // Set up header renderer for center alignment
        JTableHeader header = library_books_brs.getTableHeader();
        DefaultTableCellRenderer headerRenderer = (DefaultTableCellRenderer) header.getDefaultRenderer();
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        
        
        //lms_books_table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        library_books_brs.getTableHeader().setForeground(Color.BLACK);
        library_books_brs.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        library_books_brs.setRowHeight(25);
        library_books_brs.setSelectionBackground(new Color(109,139,116));
        library_books_brs.setSelectionForeground(Color.WHITE);
        
        String url = "jdbc:h2:~/test";
        String user = "sa";
        String database_password = "glen";

        try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
            String sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String accNo = resultSet.getString("acc_no");
                        String bookTitle = resultSet.getString("book_title");
                        String bookAuthor = resultSet.getString("book_author");
                        String bookCategory = resultSet.getString("book_category");
                        int bookAvailable = resultSet.getInt("book_available");
                        String bookBorrow = resultSet.getString("book_borrow");
                        String publicationYear = resultSet.getString("publication_year");
                        String bookDescription = resultSet.getString("book_description");
                        
                        byte[] imageData = resultSet.getBytes("book_image");
                        ImageIcon bookImageIcon = new ImageIcon(imageData);
                        model.addRow(new Object[]{accNo, bookTitle.toUpperCase(), bookAuthor.toUpperCase(), bookCategory.toUpperCase(), bookAvailable, bookBorrow.toUpperCase(), publicationYear, bookDescription, bookImageIcon});
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        int columnIndexToHide2 = 7;
    int columnIndexToHide = 8;  // Assuming 0-based indexing
        if (columnIndexToHide < library_books_brs.getColumnCount()) {
            TableColumn column = library_books_brs.getColumnModel().getColumn(columnIndexToHide);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide);
        }
        if (columnIndexToHide2 < library_books_brs.getColumnCount()) {
            TableColumn column2 = library_books_brs.getColumnModel().getColumn(columnIndexToHide2);
            column2.setMinWidth(0);
            column2.setMaxWidth(0);
            column2.setPreferredWidth(0);
       } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide2);
       }
        
}




private static void filterTableField() {
        DefaultTableModel model = (DefaultTableModel) library_books_brs.getModel();
        String searchText = search_books_field.getText().trim().toUpperCase();
       

        // Remove all rows from the table
        model.setRowCount(0);

        String url = "jdbc:h2:~/test";
        String user = "sa";
        String database_password = "glen";

        try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
    String sql;
    if (searchText.isEmpty()) {
        // Display all books if the search text is empty
        sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1";
    } else {
        // Display filtered books based on search text
        sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1 AND (UPPER(acc_no) LIKE ? OR UPPER(book_title) LIKE ?)";
    }

    try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
        if (!searchText.isEmpty()) {
            preparedStatement.setString(1, "%" + searchText + "%");
            preparedStatement.setString(2, "%" + searchText + "%");
        }

        try (ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                String accNo = resultSet.getString("acc_no");
                String bookTitle = resultSet.getString("book_title");
                String bookAuthor = resultSet.getString("book_author");
                String bookCategory = resultSet.getString("book_category");
                int bookAvailable = resultSet.getInt("book_available");
                String bookBorrow = resultSet.getString("book_borrow");
                String publicationYear = resultSet.getString("publication_year");
                String bookDescription = resultSet.getString("book_description");
                byte[] imageData = resultSet.getBytes("book_image");
                ImageIcon bookImageIcon = new ImageIcon(imageData);
                model.addRow(new Object[]{accNo, bookTitle.toUpperCase(), bookAuthor.toUpperCase(), bookCategory.toUpperCase(), bookAvailable, bookBorrow.toUpperCase(), publicationYear, bookDescription, bookImageIcon});
            }
        }
    }
} catch (SQLException e) {
    e.printStackTrace();
}
        int columnIndexToHide2 = 7;
    int columnIndexToHide = 8;  // Assuming 0-based indexing
        if (columnIndexToHide < library_books_brs.getColumnCount()) {
            TableColumn column = library_books_brs.getColumnModel().getColumn(columnIndexToHide);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide);
        }
        if (columnIndexToHide2 < library_books_brs.getColumnCount()) {
            TableColumn column2 = library_books_brs.getColumnModel().getColumn(columnIndexToHide2);
            column2.setMinWidth(0);
            column2.setMaxWidth(0);
            column2.setPreferredWidth(0);
       } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide2);
       }
    }
private static void displayBooksByCategory(String selectedCategory) {
    DefaultTableModel model = (DefaultTableModel) library_books_brs.getModel();
    model.setRowCount(0); // Clear existing rows from the table
    
    String url = "jdbc:h2:~/test";
    String user = "sa";
    String database_password = "glen";

    try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
        String sql;
        if (selectedCategory.isEmpty()) {
            // Display all books if the category is empty
            sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1";
        } else {
            // Update the SQL query to filter by selected category
            sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1 AND book_category = ?";
        }

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            if (!selectedCategory.isEmpty()) {
                preparedStatement.setString(1, selectedCategory);
            }

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    // Retrieve data from the result set
                    String accNo = resultSet.getString("acc_no");
                    String bookTitle = resultSet.getString("book_title");
                    String bookAuthor = resultSet.getString("book_author");
                    String bookCategory = resultSet.getString("book_category");
                    int bookAvailable = resultSet.getInt("book_available");
                    String bookBorrow = resultSet.getString("book_borrow");
                    String publicationYear = resultSet.getString("publication_year");
                    String bookDescription = resultSet.getString("book_description");
                    byte[] imageData = resultSet.getBytes("book_image");
                    ImageIcon bookImageIcon = new ImageIcon(imageData);

                    // Add a new row to the table model
                    model.addRow(new Object[]{accNo, bookTitle.toUpperCase(), bookAuthor.toUpperCase(), bookCategory.toUpperCase(), bookAvailable, bookBorrow.toUpperCase(), publicationYear, bookDescription, bookImageIcon});
                }
                
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    int columnIndexToHide2 = 7;
    int columnIndexToHide = 8;  // Assuming 0-based indexing
        if (columnIndexToHide < library_books_brs.getColumnCount()) {
            TableColumn column = library_books_brs.getColumnModel().getColumn(columnIndexToHide);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide);
        }
        if (columnIndexToHide2 < library_books_brs.getColumnCount()) {
            TableColumn column2 = library_books_brs.getColumnModel().getColumn(columnIndexToHide2);
            column2.setMinWidth(0);
            column2.setMaxWidth(0);
            column2.setPreferredWidth(0);
       } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide2);
       }
}
private static void displayBooksPubYear(String selectedPubYear) {
    DefaultTableModel model = (DefaultTableModel) library_books_brs.getModel();
    model.setRowCount(0); 
    
    String url = "jdbc:h2:~/test";
    String user = "sa";
    String database_password = "glen";

    try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
        String sql;
        if (selectedPubYear.isEmpty()) {
            
            sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1";
        } else {
            
            sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1 AND publication_year = ?";
        }

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            if (!selectedPubYear.isEmpty()) {
                preparedStatement.setString(1, selectedPubYear);
            }

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    
                    String accNo = resultSet.getString("acc_no");
                    String bookTitle = resultSet.getString("book_title");
                    String bookAuthor = resultSet.getString("book_author");
                    String bookCategory = resultSet.getString("book_category");
                    int bookAvailable = resultSet.getInt("book_available");
                    String bookBorrow = resultSet.getString("book_borrow");
                    String publicationYear = resultSet.getString("publication_year");
                    String bookDescription = resultSet.getString("book_description");
                    byte[] imageData = resultSet.getBytes("book_image");
                    ImageIcon bookImageIcon = new ImageIcon(imageData);
                    
                    model.addRow(new Object[]{accNo, bookTitle.toUpperCase(), bookAuthor.toUpperCase(), bookCategory.toUpperCase(), bookAvailable, bookBorrow.toUpperCase(), publicationYear, bookDescription, bookImageIcon});
                    
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    int columnIndexToHide2 = 7;
    int columnIndexToHide = 8;  // Assuming 0-based indexing
        if (columnIndexToHide < library_books_brs.getColumnCount()) {
            TableColumn column = library_books_brs.getColumnModel().getColumn(columnIndexToHide);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide);
        }
        if (columnIndexToHide2 < library_books_brs.getColumnCount()) {
            TableColumn column2 = library_books_brs.getColumnModel().getColumn(columnIndexToHide2);
            column2.setMinWidth(0);
            column2.setMaxWidth(0);
            column2.setPreferredWidth(0);
       } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide2);
       }

}
private static void displayBooksAvailable(String book_availble) {
    DefaultTableModel model = (DefaultTableModel) library_books_brs.getModel();
    model.setRowCount(0); 
    
    String url = "jdbc:h2:~/test";
    String user = "sa";
    String database_password = "glen";

    try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
        String sql;
        if (book_availble.isEmpty()) {
            
            sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1";
        } else {
            
            sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1 AND book_available = ?";
        }

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            if (!book_availble.isEmpty()) {
                preparedStatement.setString(1, book_availble);
            }

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    
                    String accNo = resultSet.getString("acc_no");
                    String bookTitle = resultSet.getString("book_title");
                    String bookAuthor = resultSet.getString("book_author");
                    String bookCategory = resultSet.getString("book_category");
                    int bookAvailable = resultSet.getInt("book_available");
                    String bookBorrow = resultSet.getString("book_borrow");
                    String publicationYear = resultSet.getString("publication_year");
                    String bookDescription = resultSet.getString("book_description");
                    
                    byte[] imageData = resultSet.getBytes("book_image");
                    ImageIcon bookImageIcon = new ImageIcon(imageData);
  
                    
                    model.addRow(new Object[]{accNo, bookTitle.toUpperCase(), bookAuthor.toUpperCase(), bookCategory.toUpperCase(), bookAvailable, bookBorrow.toUpperCase(), publicationYear, bookDescription, bookImageIcon});
                }
            }
        }
        
    } catch (SQLException e) {
        e.printStackTrace();
    }
    int columnIndexToHide = 8;
    int columnIndexToHide2 = 7;// Assuming 0-based indexing
        if (columnIndexToHide < library_books_brs.getColumnCount()) {
            TableColumn column = library_books_brs.getColumnModel().getColumn(columnIndexToHide);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide);
        }
        if (columnIndexToHide2 < library_books_brs.getColumnCount()) {
    TableColumn column2 = library_books_brs.getColumnModel().getColumn(columnIndexToHide2);
    column2.setMinWidth(0);
    column2.setMaxWidth(0);
    column2.setPreferredWidth(0);
       } else {
    System.out.println("Invalid column index to hide: " + columnIndexToHide2);
       }
}
public static void displayCartBooks() {
    DefaultTableModel model = (DefaultTableModel) book_cart_data.getModel();
    model.setRowCount(0); // Clear existing rows from the table

    // Set up cell renderer for center alignment
    DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
    centerRenderer.setHorizontalAlignment(JLabel.CENTER);

    // Apply the renderer to all columns in the table
    int columnCount = book_cart_data.getColumnCount();
    for (int i = 0; i < columnCount; i++) {
        book_cart_data.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
    }

    // Set up header renderer for center alignment
    JTableHeader header = book_cart_data.getTableHeader();
    DefaultTableCellRenderer headerRenderer = (DefaultTableCellRenderer) header.getDefaultRenderer();
    headerRenderer.setHorizontalAlignment(JLabel.CENTER);

    //lms_books_table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
    book_cart_data.getTableHeader().setForeground(Color.BLACK);
    book_cart_data.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    book_cart_data.setRowHeight(25);
    book_cart_data.setSelectionBackground(new Color(109, 139, 116));
    book_cart_data.setSelectionForeground(Color.WHITE);
     
    
    
    String url = "jdbc:h2:~/test";
    String user = "sa";
    String database_password = "glen";
    String studentID = getStudNo;
    try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
        String sql = "SELECT SC.studentID, SC.acc_no, LB.book_title, LB.book_author, LB.book_category, LB.book_available, LB.publication_year, SC.date_added " +
                "FROM STUDENT_CART SC " +
                "JOIN LIBRARY_BOOKS LB ON SC.acc_no = LB.acc_no " +
                "WHERE SC.studentID = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            // Set the parameter for studentID
            preparedStatement.setString(1, studentID);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {

                    String accNo = resultSet.getString("acc_no");
                    String bookTitle = resultSet.getString("book_title");
                    String bookAuthor = resultSet.getString("book_author");
                    String bookCategory = resultSet.getString("book_category");
                    int bookAvailable = resultSet.getInt("book_available");
                    String publicationYear = resultSet.getString("publication_year");
                    String dateAdded = resultSet.getString("date_added");
                    model.addRow(new Object[]{studentID, accNo, bookTitle.toUpperCase(), bookAuthor.toUpperCase(), bookCategory.toUpperCase(), bookAvailable, publicationYear, dateAdded});
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    int columnIndexToHide = 0;
    if (columnIndexToHide < book_cart_data.getColumnCount()) {
            TableColumn column = book_cart_data.getColumnModel().getColumn(columnIndexToHide);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide);
        }
    
    }
    public static void displayBookRequested() {
    DefaultTableModel model = (DefaultTableModel) requested_book_data.getModel();
    model.setRowCount(0); // Clear existing rows from the table

    // Set up cell renderer for center alignment
    DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
    centerRenderer.setHorizontalAlignment(JLabel.CENTER);

    // Apply the renderer to all columns in the table
    int columnCount = requested_book_data.getColumnCount();
    for (int i = 0; i < columnCount; i++) {
        requested_book_data.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
    }

    // Set up header renderer for center alignment
    JTableHeader header = requested_book_data.getTableHeader();
    DefaultTableCellRenderer headerRenderer = (DefaultTableCellRenderer) header.getDefaultRenderer();
    headerRenderer.setHorizontalAlignment(JLabel.CENTER);

    //lms_books_table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
    requested_book_data.getTableHeader().setForeground(Color.BLACK);
    requested_book_data.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    requested_book_data.setRowHeight(25);
    requested_book_data.setSelectionBackground(new Color(109, 139, 116));
    requested_book_data.setSelectionForeground(Color.WHITE);
     
    
    
    String url = "jdbc:h2:~/test";
    String user = "sa";
    String database_password = "glen";
    String studentID = getStudNo;
    try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
        String sql = "SELECT RB.studentID, RB.acc_no, LB.book_title, LB.book_author, LB.book_category, LB.book_available, LB.publication_year, RB.date_added " +
                "FROM REQUESTED_BOOKS RB " +
                "JOIN LIBRARY_BOOKS LB ON RB.acc_no = LB.acc_no " +
                "WHERE RB.studentID = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            // Set the parameter for studentID
            preparedStatement.setString(1, studentID);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {

                    String accNo = resultSet.getString("acc_no");
                    String bookTitle = resultSet.getString("book_title");
                    String bookAuthor = resultSet.getString("book_author");
                    String bookCategory = resultSet.getString("book_category");
                    int bookAvailable = resultSet.getInt("book_available");
                    String publicationYear = resultSet.getString("publication_year");
                    String dateAdded = resultSet.getString("date_added");
                    model.addRow(new Object[]{studentID, accNo, bookTitle.toUpperCase(), bookAuthor.toUpperCase(), bookCategory.toUpperCase(), bookAvailable, publicationYear, dateAdded});
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    int columnIndexToHide = 0;
    int columnIndexToHide2 = 5;
      // Assuming 0-based indexing
        if (columnIndexToHide < requested_book_data.getColumnCount()) {
            TableColumn column = requested_book_data.getColumnModel().getColumn(columnIndexToHide);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide);
        }
        
      // Assuming 0-based indexing
        if (columnIndexToHide2 < requested_book_data.getColumnCount()) {
            TableColumn column = requested_book_data.getColumnModel().getColumn(columnIndexToHide2);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide);
        }
    
    }
    public static void displayBookBorrowers() {
    DefaultTableModel model = (DefaultTableModel) book_borrowers_data.getModel();
    model.setRowCount(0); // Clear existing rows from the table

    // Set up cell renderer for center alignment
    DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
    centerRenderer.setHorizontalAlignment(JLabel.CENTER);

    // Apply the renderer to all columns in the table
    int columnCount = book_borrowers_data.getColumnCount();
    for (int i = 0; i < columnCount; i++) {
        book_borrowers_data.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
    }

    // Set up header renderer for center alignment
    JTableHeader header = book_borrowers_data.getTableHeader();
    DefaultTableCellRenderer headerRenderer = (DefaultTableCellRenderer) header.getDefaultRenderer();
    headerRenderer.setHorizontalAlignment(JLabel.CENTER);

    //lms_books_table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
    book_borrowers_data.getTableHeader().setForeground(Color.BLACK);
    book_borrowers_data.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    book_borrowers_data.setRowHeight(25);
    book_borrowers_data.setSelectionBackground(new Color(109, 139, 116));
    book_borrowers_data.setSelectionForeground(Color.WHITE);
     
    
    
    String url = "jdbc:h2:~/test";
    String user = "sa";
    String database_password = "glen";
    String studentID = getStudNo;
    try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
        String sql = "SELECT BR.studentID, BR.acc_no, LB.book_title, LB.book_author, LB.book_category, LB.publication_year, BR.date_added, BR.return_duedate, BR.book_penalty " +
                "FROM BOOK_BORROWERS BR " +
                "JOIN LIBRARY_BOOKS LB ON BR.acc_no = LB.acc_no " +
                "WHERE BR.studentID = ?";
                
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            // Set the parameter for studentID
            preparedStatement.setString(1, studentID);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    //String StudID = resultSet.getString("studentID");
                    String accNo = resultSet.getString("acc_no");
                    String bookTitle = resultSet.getString("book_title");
                    String bookAuthor = resultSet.getString("book_author");
                    String bookCategory = resultSet.getString("book_category");
                    //int bookAvailable = resultSet.getInt("book_available");
                    String publicationYear = resultSet.getString("publication_year");
                    String dateAdded = resultSet.getString("date_added");
                    String returnDate = resultSet.getString("return_duedate");
                    int bookPenalty = resultSet.getInt("book_penalty");
                    model.addRow(new Object[]{getStudNo, accNo, bookTitle.toUpperCase(), bookAuthor.toUpperCase(), bookCategory.toUpperCase(), publicationYear, dateAdded, returnDate, bookPenalty });
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    public static void displayAnnouncement(){
    String url = "jdbc:h2:~/test";
        String user = "sa";
        String database_password = "glen";

        try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
            String sql = "SELECT * FROM LIBRARY_ANNOUNCEMENT";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String announcement_lib = resultSet.getString("announcement");
                        lib_announcement.setText(announcement_lib);
                        
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    
    }
    
    
}


