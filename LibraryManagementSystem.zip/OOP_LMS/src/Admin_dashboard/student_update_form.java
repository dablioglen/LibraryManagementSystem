/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Admin_dashboard;

import static Admin_dashboard.admin_dashboard.DisplayAdminData;
import static Admin_dashboard.admin_dashboard.DisplayTotalStudent;
import static Admin_dashboard.admin_to_update.DisplayAdminDataU;
import static Admin_dashboard.student_update_table.DisplayStudentData;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.imageio.ImageIO;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.LookAndFeel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author dabli
 */
public class student_update_form extends javax.swing.JFrame {
    private String updated_student_id;
    private String updated_stud_pass;
    private String updated_stud_fn;
    private String updated_stud_ln;
    private String updated_stud_sex;
    private String updated_stud_email;
    private String updated_stud_tel;
    private String updated_stud_address;
    private String updated_stud_course;
    private String updated_stud_year;
    private String updated_stud_section;
    private String updated_stud_age;
    private String updated_stud_status;
    private byte[] updatedStudImageBytes;
    private ImageIcon selectedImage = null;
    
    private ImageIcon updatedImage = new ImageIcon();
     
    private ImageIcon scaleImage(ImageIcon icon, int width, int height) {
    Image img = icon.getImage();
    Image scaledImage = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
    return new ImageIcon(scaledImage);
    
    } 
    /**
     * Creates new form student_update_form
     */
    public student_update_form() {
        initComponents();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    public void setStudentUpdateDetails(String studID, String passwd, String fn, String ln, String studAge, 
            String studSx, String studEml, String studTel, String studHomeAdd, String studCourse, 
            String studYear, String StudSec, ImageIcon studImage, String studStatus ){
    
        int fixedWidth = 100; // Adjust the width as needed
        int fixedHeight = 100; // Adjust the height as needed
        Image scaledStudImage = studImage.getImage().getScaledInstance(fixedWidth, fixedHeight, Image.SCALE_SMOOTH);
        studImg.setIcon(new ImageIcon(scaledStudImage));
        stud_id_no.setText(studID);
        stud_fn.setText(fn);
        stud_ln.setText(ln);
        stud_age.setText(studAge);
        stud_sex.setName("studSexCombobox");
        stud_course.setName("studCourseCombobox");
        stud_year.setName("studYearCombobox");
        setComboBoxSelectedItem(stud_sex, studSx);
        setComboBoxSelectedItem(stud_course, studCourse);
        setComboBoxSelectedItem(stud_year, studYear);
        stud_email.setText(studEml);
        stud_address.setText(studHomeAdd);
        stud_tel.setText(studTel);
        stud_status.setText(studStatus);
        stud_passworD.setText(passwd);
        stud_section.setText(StudSec);
        
       
    
        
    
    }
     private void setComboBoxSelectedItem(JComboBox<String> comboBox, String value) {
    if (comboBox.getName() != null) {
        String trimmedValue = value.trim();
        DefaultComboBoxModel<String> model = (DefaultComboBoxModel<String>) comboBox.getModel();

        // Print for debugging
        //System.out.println("Setting value in " + comboBox.getName() + ": " + trimmedValue);

        // Check if the value exists in the model
        int index = model.getIndexOf(trimmedValue);
        if (index != -1) {
            comboBox.setSelectedIndex(index);
        } else {
            System.out.println("Value not found in " + comboBox.getName() + " model: " + trimmedValue);
            System.out.println("Available items in " + comboBox.getName() + " model: " + model.toString());
        }
    } else {
        System.out.println("ComboBox name is null");
    }
}
     private byte[] convertImageIconToBytes(ImageIcon icon) {
    if (icon == null || icon.getIconWidth() <= 0 || icon.getIconHeight() <= 0) {
        // Handle the case where the icon or its dimensions are invalid
        return new byte[0]; // Or throw an exception, log an error, etc.
    }

    BufferedImage bufferedImage = new BufferedImage(
            icon.getIconWidth(),
            icon.getIconHeight(),
            BufferedImage.TYPE_INT_ARGB
    );

    icon.paintIcon(null, bufferedImage.getGraphics(), 0, 0);

    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

    try {
        ImageIO.write(bufferedImage, "png", byteArrayOutputStream);
    } catch (IOException e) {
        e.printStackTrace();
        // Handle the exception as appropriate
    }

    return byteArrayOutputStream.toByteArray();
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        studImg = new javax.swing.JLabel();
        stud_id_no = new javax.swing.JTextField();
        stud_fn = new javax.swing.JTextField();
        stud_ln = new javax.swing.JTextField();
        stud_email = new javax.swing.JTextField();
        stud_age = new javax.swing.JTextField();
        stud_sex = new javax.swing.JComboBox<>();
        stud_address = new javax.swing.JTextField();
        stud_tel = new javax.swing.JTextField();
        stud_course = new javax.swing.JComboBox<>();
        stud_year = new javax.swing.JComboBox<>();
        stud_section = new javax.swing.JTextField();
        stud_status = new javax.swing.JTextField();
        stud_passworD = new javax.swing.JTextField();
        updates_student_dataF = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(182, 196, 182));

        jPanel2.setBackground(new java.awt.Color(109, 139, 116));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("UPDATE STUDENT");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        studImg.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        studImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                studImgMouseClicked(evt);
            }
        });

        stud_id_no.setEditable(false);
        stud_id_no.setText("jTextField1");

        stud_fn.setText("fn");

        stud_ln.setText("ln");

        stud_email.setText("email");

        stud_age.setText("age");

        stud_sex.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "MALE", "FEMALE" }));

        stud_address.setText("address");

        stud_tel.setText("tel");

        stud_course.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Bachelor in Electronics Engineering", "Bachelor of Science in Computer Engineering", "Bachelor in Information Technology with Specialization in Cybersecurity", "Bachelor in Information Technology with Specialization in Data Science", "Bachelor of Science in Information Technology", "Bachelor of Science in Nursing", "Bachelor of Science in Physical Therapy", "Bachelor in Physical Education Major in School of Physical Education", "BSED Major in English", "BSED Major in General Science", "BSED Major in Mathematics", "BSED Major in Social Studies", "BTVTE Major in Automotive (2nd-4th Year)", "BTVTE Major in Computer Programming Technology (2nd-4th Year)", "BTVTE Major in Electrical Technology (2nd-4th Year)", "BTVTE Major in Electronics Technology (2nd-4th Year)", "BTVTE Major in Food Service Management Technology (2nd-4th Year)", "BTVTE Major in Garments Technology (2nd-4th Year)", "BTVTE Major in Hotel and Restaurant Services Technology (2nd-4th Year)", "BTVTE Major in Heating, Ventilation and Air Conditioning Technology (2nd-4th Year)", "Bachelor of Science in Accountancy", "Bachelor of Science in Accounting Information System", "BS in Business Administration Major in Economics", "BS in Business Administration Major in Human Resource Development Management", "BS in Business Administration Major in Marketing Management", "Bachelor of Science in Entrepreneurship", "Bachelor of Arts in Communication", "Bachelor of Arts in Political Science", "Bachelor in Public Administration", "Bachelor in Public Administration – Special Program", "BS in Mathematics Major in Computer Science", "Bachelor of Science in Psychology", "Bachelor of Science in Social Work", "Master of Arts in Education (MAEd) major in Educational Administration", "Master in Business Administration (MBA)", "Master in Public Management and Governance (MPMG)", "Master of Science in Criminal Justice (MSCJ) with specialization in Criminology", "Doctor of Philosophy (PhD) major in Educational Policy and Administration", "Accountancy, Business and Management (ABM)", "General Academic (GAS)", "Technical Vocational in Home Economics (HE)", "Humanities and Social Science (HUMSS)", "Technical Vocational in Information, Communication & Technology (ICT)", "Science, Technology, Engineering and Mathematics (STEM)" }));

        stud_year.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Grade 11", "Grade 12", "1st Year", "2nd Year", "3rd Year", "4th Year" }));

        stud_section.setText("jTextField8");

        stud_status.setEditable(false);
        stud_status.setText("status");

        stud_passworD.setText("password");

        updates_student_dataF.setText("Update");
        updates_student_dataF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updates_student_dataFActionPerformed(evt);
            }
        });

        jButton2.setText("Cancel");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel2.setText("         FIRST NAME");

        jLabel3.setText("          LAST NAME");

        jLabel4.setText("                  SEX");

        jLabel5.setText("                  AGE");

        jLabel6.setText("               EMAIL");

        jLabel7.setText("      HOME ADDRESS");

        jLabel8.setText("              TEL NO.");

        jLabel9.setText("               STATUS");

        jLabel10.setText("            COURSE");

        jLabel11.setText("               YEAR");

        jLabel12.setText("            SECTION");

        jLabel13.setText("           PASSWORD");

        jLabel14.setText("    STUDENT ID");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(studImg, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(stud_id_no, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(12, 12, 12)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(stud_fn, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(stud_email, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(stud_ln, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(stud_address, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(stud_sex, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(stud_tel, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(stud_age, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(stud_status, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(stud_course, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(stud_year, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(stud_section, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(stud_passworD, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(118, 118, 118)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(updates_student_dataF)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton2))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(0, 20, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(studImg, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(stud_id_no, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(stud_fn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(jLabel2)
                        .addGap(12, 12, 12)
                        .addComponent(stud_email, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(5, 5, 5)
                        .addComponent(jLabel6))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(stud_ln, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(jLabel3)
                        .addGap(12, 12, 12)
                        .addComponent(stud_address, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(5, 5, 5)
                        .addComponent(jLabel7))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(stud_sex, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(jLabel4)
                        .addGap(12, 12, 12)
                        .addComponent(stud_tel, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(5, 5, 5)
                        .addComponent(jLabel8))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(stud_age, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(jLabel5)
                        .addGap(12, 12, 12)
                        .addComponent(stud_status, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(5, 5, 5)
                        .addComponent(jLabel9)))
                .addGap(6, 6, 6)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addComponent(stud_course, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(stud_year, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(stud_section, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(stud_passworD, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12)
                    .addComponent(jLabel13))
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(updates_student_dataF, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55))
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void updates_student_dataFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updates_student_dataFActionPerformed
        // TODO add your handling code here:
        updated_student_id = stud_id_no.getText();
        updated_stud_pass = stud_passworD.getText();
        updated_stud_fn = stud_fn.getText();
        updated_stud_ln = stud_ln.getText();
        updated_stud_sex = (String) stud_sex.getSelectedItem();
        updated_stud_email = stud_email.getText();
        updated_stud_tel = stud_tel.getText();
        updated_stud_address = stud_address.getText();
        updated_stud_course = (String) stud_course.getSelectedItem();
        updated_stud_year = (String) stud_year.getSelectedItem();
        updated_stud_section = stud_section.getText();
        updated_stud_age = stud_age.getText();
        //updated_stud_status = stud_status.getText();
        
        if (selectedImage == null) {
    // Set default image bytes to updatedBookImageBytes
           updatedStudImageBytes = getDefaultImageBytes();
    
    // Retrieve the default ImageIcon from bkImg and assign it to updatedImage
          updatedImage = (ImageIcon) studImg.getIcon();
          } else {
    // Convert the selectedImage to bytes and assign it to updatedBookImageBytes
         updatedStudImageBytes = convertImageIconToBytes(selectedImage);
         }
        String url = "jdbc:h2:~/test";
    String user = "sa";
    String database_password = "glen";

try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
    // SQL query to update data in the table
    String sql = "UPDATE LMSTUDENTS SET first_name=?, last_name =?, password=?, student_age=?, sex=?, email=?, home_address =?, telephone_no=?, course=?, student_year=?, section=?, student_image=?  WHERE studentID=?";

    try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
        // Set values for prepared statement
        preparedStatement.setString(1, updated_stud_fn);
        preparedStatement.setString(2, updated_stud_ln);
        preparedStatement.setString(3, updated_stud_pass);
        preparedStatement.setString(4, updated_stud_age);
        preparedStatement.setString(5, updated_stud_sex);
        preparedStatement.setString(6, updated_stud_email);
       preparedStatement.setString(7, updated_stud_address);
       preparedStatement.setString(8, updated_stud_tel);
       preparedStatement.setString(9, updated_stud_course);
       preparedStatement.setString(10, updated_stud_year);
        //preparedStatement.setString(8, updated_admin_status);
        preparedStatement.setString(11, updated_stud_section);
         preparedStatement.setBytes(12, updatedStudImageBytes);
         preparedStatement.setString(13, updated_student_id);
         
        // Print values for debugging
    

        // Execute the query
        int rowsAffected = preparedStatement.executeUpdate();

        if (rowsAffected > 0) {
            System.out.println("Update successful.");
            DisplayStudentData();
            DisplayTotalStudent();
            
            this.dispose();
            
            JOptionPane.showMessageDialog(this, "Student "+updated_student_id+" is updated", "", JOptionPane.INFORMATION_MESSAGE);
            // Additional actions after successful update
            // For example, refresh UI or perform other tasks
        } else {
            System.out.println("No records were updated.");
            // Handle the case where no records were updated
        }
    }
} catch (SQLException e) {
    e.printStackTrace();
    // Handle SQLException, log the error, or display an error message
}
    
    }//GEN-LAST:event_updates_student_dataFActionPerformed

    private void studImgMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_studImgMouseClicked
        // TODO add your handling code here:
        try {
        // Save the current look and feel
        LookAndFeel savedLaf = UIManager.getLookAndFeel();

        // Set the Metal look and feel for JFileChooser
        UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());

        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(this);

        // Reset the original look and feel
        UIManager.setLookAndFeel(savedLaf);

        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            String imagePath = selectedFile.getAbsolutePath();

            // Set the selected image to the JLabel
            selectedImage = new ImageIcon(imagePath);

            // Scale the image to fit the default size of image_view (e.g., 128x128)
            int defaultWidth = 100;
            int defaultHeight = 100;
            selectedImage = scaleImage(selectedImage, defaultWidth, defaultHeight);

            studImg.setIcon(selectedImage);
            updatedImage = (ImageIcon) studImg.getIcon();
            
        }
    } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
        java.util.logging.Logger.getLogger(update_book.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    }  
    }//GEN-LAST:event_studImgMouseClicked
    
    private byte[] convertImageIconToByteArray(ImageIcon icon) {
    if (icon == null) {
        return null;
    }

    BufferedImage bufferedImage = new BufferedImage(icon.getIconWidth(), icon.getIconHeight(), BufferedImage.TYPE_INT_RGB);
    Graphics g = bufferedImage.createGraphics();
    icon.paintIcon(null, g, 0, 0);
    g.dispose();

    try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
        ImageIO.write(bufferedImage, "png", baos);
        return baos.toByteArray();
    } catch (IOException e) {
        e.printStackTrace();
    }

    return null;
    
    
   
}
     private byte[] getDefaultImageBytes() {
    // Get the Icon from bkImg
    ImageIcon defaultImageIcon = (ImageIcon) studImg.getIcon();

    // Check if no new image is selected
    if (selectedImage == null) {
        // Use the default image from bkImg
        return convertImageIconToBytes(defaultImageIcon);
    } else {
        // Convert the selected image to bytes
        return convertImageIconToBytes(selectedImage);
    }
}

private byte[] convertBufferedImageToBytes(BufferedImage image) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    try {
        ImageIO.write(image, "jpg", byteArrayOutputStream);
    } catch (IOException e) {
        e.printStackTrace();
        // Handle the exception or return an empty byte array
        return new byte[0];
    }
    return byteArrayOutputStream.toByteArray();
}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(student_update_form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(student_update_form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(student_update_form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(student_update_form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new student_update_form().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel studImg;
    private javax.swing.JTextField stud_address;
    private javax.swing.JTextField stud_age;
    private javax.swing.JComboBox<String> stud_course;
    private javax.swing.JTextField stud_email;
    private javax.swing.JTextField stud_fn;
    private javax.swing.JTextField stud_id_no;
    private javax.swing.JTextField stud_ln;
    private javax.swing.JTextField stud_passworD;
    private javax.swing.JTextField stud_section;
    private javax.swing.JComboBox<String> stud_sex;
    private javax.swing.JTextField stud_status;
    private javax.swing.JTextField stud_tel;
    private javax.swing.JComboBox<String> stud_year;
    private javax.swing.JButton updates_student_dataF;
    // End of variables declaration//GEN-END:variables
}
