/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Admin_dashboard;

import Add_admin.add_admin;
import static Admin_dashboard.admin_dashboard.displayBooksInTable;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.LookAndFeel;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import static javax.swing.UIManager.getIcon;
import javax.swing.UnsupportedLookAndFeelException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
/**
 *
 * @author dabli
 */
public class update_book extends javax.swing.JFrame {
    private String getAcc;
    private String updatedBookTitle;
    private String updatedAuthor;
    private String updatedCategory;
    private String updatedBorrow;
    private String updatedPubYear;
    private String updatedDescription;
    //private ImageIcon updatedBookImageIcon;
    private byte[] updatedBookImageBytes;
    private String accNo;
    private ImageIcon selectedImage = null;
    private ImageIcon updatedImage = new ImageIcon(); // Initialize with an empty ImageIcon

    private ImageIcon scaleImage(ImageIcon icon, int width, int height) {
    Image img = icon.getImage();
    Image scaledImage = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
    return new ImageIcon(scaledImage);
    
    } 
    /**
     * Creates new form update_book
     */
    public update_book() {
        initComponents();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    public void setUpdateDetails(String accNo, String bookTitle, String bkAuthor, String bkCategory, 
        String bkBorrow, String bkPubYear, String bkDescription, ImageIcon bkImage ){
        comboboxCategory.setName("CategoryComboBox");
        combobox_pubYear.setName("PubYearComboBox");
        combobox_bk_borrow.setName("BorrowComboBox");

   

    // Set values from JTextFields to JComboBoxes
    setComboBoxSelectedItem(comboboxCategory, bkCategory);
    setComboBoxSelectedItem(combobox_pubYear, bkPubYear);
    setComboBoxSelectedItem(combobox_bk_borrow, bkBorrow);

        accNm.setText(accNo);
        accNm.setHorizontalAlignment(SwingConstants.CENTER);
        int fixedWidth = 100; // Adjust the width as needed
        int fixedHeight = 130; // Adjust the height as needed
        Image scaledBookImage = bkImage.getImage().getScaledInstance(fixedWidth, fixedHeight, Image.SCALE_SMOOTH);
        bkImg.setIcon(new ImageIcon(scaledBookImage));
        //bkImg.setIcon(bkImage);
        bkT.setText(bookTitle);
        bkT.setHorizontalAlignment(SwingConstants.CENTER);
        bkAuth.setText(bkAuthor);
        bkAuth.setHorizontalAlignment(SwingConstants.CENTER);
        
        bkDescp.setText(bkDescription);
        
       
        
    
    
    }
    private void setComboBoxSelectedItem(JComboBox<String> comboBox, String value) {
    if (comboBox.getName() != null) {
        String trimmedValue = value.trim();
        DefaultComboBoxModel<String> model = (DefaultComboBoxModel<String>) comboBox.getModel();

        // Print for debugging
        //System.out.println("Setting value in " + comboBox.getName() + ": " + trimmedValue);

        // Check if the value exists in the model
        int index = model.getIndexOf(trimmedValue);
        if (index != -1) {
            comboBox.setSelectedIndex(index);
        } else {
            System.out.println("Value not found in " + comboBox.getName() + " model: " + trimmedValue);
            System.out.println("Available items in " + comboBox.getName() + " model: " + model.toString());
        }
    } else {
        System.out.println("ComboBox name is null");
    }
}
    private byte[] convertImageIconToBytes(ImageIcon icon) {
    if (icon == null || icon.getIconWidth() <= 0 || icon.getIconHeight() <= 0) {
        // Handle the case where the icon or its dimensions are invalid
        return new byte[0]; // Or throw an exception, log an error, etc.
    }

    BufferedImage bufferedImage = new BufferedImage(
            icon.getIconWidth(),
            icon.getIconHeight(),
            BufferedImage.TYPE_INT_ARGB
    );

    icon.paintIcon(null, bufferedImage.getGraphics(), 0, 0);

    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

    try {
        ImageIO.write(bufferedImage, "png", byteArrayOutputStream);
    } catch (IOException e) {
        e.printStackTrace();
        // Handle the exception as appropriate
    }

    return byteArrayOutputStream.toByteArray();
}

   

    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        bkT = new javax.swing.JTextField();
        bkImg = new javax.swing.JLabel();
        bkAuth = new javax.swing.JTextField();
        accNm = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        bkDescp = new javax.swing.JTextArea();
        update_book_bt = new javax.swing.JButton();
        remove_book_bt = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        combobox_bk_borrow = new javax.swing.JComboBox<>();
        combobox_pubYear = new javax.swing.JComboBox<>();
        comboboxCategory = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(182, 196, 182));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(109, 139, 116));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("UPDATE BOOK");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addContainerGap(420, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 524, -1));

        bkT.setText("jTextField1");
        jPanel1.add(bkT, new org.netbeans.lib.awtextra.AbsoluteConstraints(108, 46, 130, 40));

        bkImg.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        bkImg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bkImgMouseClicked(evt);
            }
        });
        jPanel1.add(bkImg, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 46, 94, 131));

        bkAuth.setText("jTextField2");
        jPanel1.add(bkAuth, new org.netbeans.lib.awtextra.AbsoluteConstraints(244, 46, 129, 40));

        accNm.setEditable(false);
        accNm.setText("jTextField7");
        jPanel1.add(accNm, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 183, 94, 40));

        bkDescp.setColumns(20);
        bkDescp.setLineWrap(true);
        bkDescp.setRows(5);
        bkDescp.setWrapStyleWord(true);
        jScrollPane1.setViewportView(bkDescp);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 113, 270, 110));

        update_book_bt.setText("Update");
        update_book_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_book_btActionPerformed(evt);
            }
        });
        jPanel1.add(update_book_bt, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 263, -1, 30));

        remove_book_bt.setText("Cancel");
        remove_book_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                remove_book_btActionPerformed(evt);
            }
        });
        jPanel1.add(remove_book_bt, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 263, -1, 30));

        jLabel2.setText("               TITLE");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(108, 92, 130, -1));

        jLabel3.setText("          CATEGORY");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(379, 92, 130, -1));

        jLabel4.setText("            AUTHOR");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(244, 92, 129, -1));

        jLabel5.setText("    PUBLICATION YEAR");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 160, 130, -1));

        jLabel8.setText("       ACC NO.");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 229, 105, -1));

        jLabel1.setText("       BOOK BORROW");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 233, 130, -1));

        combobox_bk_borrow.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "YES", "NO" }));
        jPanel1.add(combobox_bk_borrow, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 183, 130, 40));

        combobox_pubYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] {"2024", "2023", "2022", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995" }));
        jPanel1.add(combobox_pubYear, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 114, 132, 41));

        comboboxCategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] {"", "BUSINESS", "EDUCATION", "ENVIRONMENT", "INFORMATION AND PUBLISHING", "LAW", "LITERATURE", "MEDICINE", "NATION AND WORLD", "RELIGION", "SCIENCE", "SOCIAL SCIENCE", "TECHNOLOGY", "ENGINEERING", "MATHEMATICS" }));
        jPanel1.add(comboboxCategory, new org.netbeans.lib.awtextra.AbsoluteConstraints(379, 46, 130, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 524, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 311, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void update_book_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_book_btActionPerformed
        // TODO add your handling code here:
    updatedBookTitle = bkT.getText();
    updatedAuthor = bkAuth.getText();
    updatedCategory = (String) comboboxCategory.getSelectedItem();
    updatedBorrow = (String) combobox_bk_borrow.getSelectedItem();
    updatedPubYear = (String) combobox_pubYear.getSelectedItem();
    updatedDescription = bkDescp.getText();
    //updatedBookImageBytes = convertImageIconToBytes(updatedImage);
    //updatedBookImageBytes = convertImageIconToBytes((ImageIcon) bkImg.getIcon());
    

    getAcc = accNm.getText();
    if (selectedImage == null) {
    // Set default image bytes to updatedBookImageBytes
    updatedBookImageBytes = getDefaultImageBytes();
    
    // Retrieve the default ImageIcon from bkImg and assign it to updatedImage
    updatedImage = (ImageIcon) bkImg.getIcon();
} else {
    // Convert the selectedImage to bytes and assign it to updatedBookImageBytes
    updatedBookImageBytes = convertImageIconToBytes(selectedImage);
}
    
        
    String url = "jdbc:h2:~/test";
    String user = "sa";
    String database_password = "glen";

try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
    // SQL query to update data in the table
    String sql = "UPDATE LIBRARY_BOOKS SET book_title=?, book_author=?, book_category=?, book_borrow=?, publication_year=?, book_description=?, book_image=? WHERE acc_no=?";

    try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
        // Set values for prepared statement
        preparedStatement.setString(1, updatedBookTitle);
        preparedStatement.setString(2, updatedAuthor);
        preparedStatement.setString(3, updatedCategory);
        preparedStatement.setString(4, updatedBorrow);
        preparedStatement.setString(5, updatedPubYear);
        preparedStatement.setString(6, updatedDescription);
        preparedStatement.setBytes(7, updatedBookImageBytes);
        preparedStatement.setString(8, getAcc);
        
        // Print values for debugging
    

        // Execute the query
        int rowsAffected = preparedStatement.executeUpdate();

        if (rowsAffected > 0) {
            System.out.println("Update successful.");
            this.dispose();
            displayBooksInTable();
            
            JOptionPane.showMessageDialog(this, "Book "+getAcc+" is updated", "Book "+getAcc, JOptionPane.INFORMATION_MESSAGE);
            // Additional actions after successful update
            // For example, refresh UI or perform other tasks
        } else {
            System.out.println("No records were updated.");
            // Handle the case where no records were updated
        }
    }
} catch (SQLException e) {
    e.printStackTrace();
    // Handle SQLException, log the error, or display an error message
}



       
    }//GEN-LAST:event_update_book_btActionPerformed
    private byte[] getDefaultImageBytes() {
    // Get the Icon from bkImg
    ImageIcon defaultImageIcon = (ImageIcon) bkImg.getIcon();

    // Check if no new image is selected
    if (selectedImage == null) {
        // Use the default image from bkImg
        return convertImageIconToBytes(defaultImageIcon);
    } else {
        // Convert the selected image to bytes
        return convertImageIconToBytes(selectedImage);
    }
}

private byte[] convertBufferedImageToBytes(BufferedImage image) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    try {
        ImageIO.write(image, "jpg", byteArrayOutputStream);
    } catch (IOException e) {
        e.printStackTrace();
        // Handle the exception or return an empty byte array
        return new byte[0];
    }
    return byteArrayOutputStream.toByteArray();
}
    private void bkImgMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bkImgMouseClicked
        // TODO add your handling code here:
        try {
        // Save the current look and feel
        LookAndFeel savedLaf = UIManager.getLookAndFeel();

        // Set the Metal look and feel for JFileChooser
        UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());

        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(this);

        // Reset the original look and feel
        UIManager.setLookAndFeel(savedLaf);

        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            String imagePath = selectedFile.getAbsolutePath();

            // Set the selected image to the JLabel
            selectedImage = new ImageIcon(imagePath);

            // Scale the image to fit the default size of image_view (e.g., 128x128)
            int defaultWidth = 94;
            int defaultHeight = 131;
            selectedImage = scaleImage(selectedImage, defaultWidth, defaultHeight);

            bkImg.setIcon(selectedImage);
            updatedImage = (ImageIcon) bkImg.getIcon();
            
        }
    } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
        java.util.logging.Logger.getLogger(update_book.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    }
    }//GEN-LAST:event_bkImgMouseClicked

    private void remove_book_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_remove_book_btActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_remove_book_btActionPerformed
    private byte[] convertImageIconToByteArray(ImageIcon icon) {
    if (icon == null) {
        return null;
    }

    BufferedImage bufferedImage = new BufferedImage(icon.getIconWidth(), icon.getIconHeight(), BufferedImage.TYPE_INT_RGB);
    Graphics g = bufferedImage.createGraphics();
    icon.paintIcon(null, g, 0, 0);
    g.dispose();

    try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
        ImageIO.write(bufferedImage, "png", baos);
        return baos.toByteArray();
    } catch (IOException e) {
        e.printStackTrace();
    }

    return null;
    
    
   
}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(update_book.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(update_book.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(update_book.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(update_book.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new update_book().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField accNm;
    private javax.swing.JTextField bkAuth;
    private javax.swing.JTextArea bkDescp;
    private javax.swing.JLabel bkImg;
    private javax.swing.JTextField bkT;
    public javax.swing.JComboBox<String> comboboxCategory;
    public javax.swing.JComboBox<String> combobox_bk_borrow;
    public javax.swing.JComboBox<String> combobox_pubYear;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton remove_book_bt;
    private javax.swing.JButton update_book_bt;
    // End of variables declaration//GEN-END:variables
}
