/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Admin_dashboard;



import LmsBooks.add_books;
import Lms_email.send_email;
import static Student_Dashboard.student_dashboard.getStudNo;
import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.JTable;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Date;
import java.sql.Timestamp;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.text.SimpleDateFormat;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
//import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;

/**
 *
 * @author dabli
 */
public class  admin_dashboard extends javax.swing.JFrame {
Color panelcolor = new Color(182,196,182);
Color defcolor = new Color(109,139,116);
private String getannouncement;
/**
     * Creates new form admin_dashboard
     */
    public admin_dashboard() {
        initComponents();
        times();
        dt();
        displayBooksInTable();
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        countRowsAndUpdateLabel();
        countAdminsActive();
        countAdminsInactive();
        countStudent();
        countStudentActive();
        countStudentInactive();
        countBooks();
        refreshTable();
        DisplayAdminData();
        DisplayActiveAdmin();
        DisplayInactiveAdmin();
        DisplayTotalStudent();
        DisplayActiveStudent();
        DisplayInactiveStudent();
        displayRequestBookData();
        displayBookBorrowers();
        displayAnnouncement();
        
        lms_books_table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 1) {
                    // Get the selected row and column
                    int selectedRow = lms_books_table.getSelectedRow();
                    
                    // Ensure a valid row is selected
                    if (selectedRow != -1) {
                        // Get the data from the selected row
                        String accNo = (String) lms_books_table.getValueAt(selectedRow, 0);
                        String bookTitle = (String) lms_books_table.getValueAt(selectedRow, 1);
                        String bookAuthor = (String) lms_books_table.getValueAt(selectedRow, 2);
                        String bookCategory = (String) lms_books_table.getValueAt(selectedRow, 3);
                        int bookAve = (int) lms_books_table.getValueAt(selectedRow, 4);
                        String bookBrw = (String) lms_books_table.getValueAt(selectedRow, 5);
                        String publicationYear = (String) lms_books_table.getValueAt(selectedRow, 6);
                        String bookDescription = (String) lms_books_table.getValueAt(selectedRow, 7);
                        ImageIcon bookImageIcon = (ImageIcon) lms_books_table.getValueAt(selectedRow, 8);
                        
                        // Open the new frame with the selected data
                       BookDetailsAction(accNo, bookTitle, bookAuthor, bookCategory, bookAve, 
                               bookBrw, publicationYear, bookDescription, bookImageIcon );
                    }
                }
            }
        });
         manage_request_data.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 1) {
                    // Get the selected row and column
                    int selectedRow = manage_request_data.getSelectedRow();
                    
                    // Ensure a valid row is selected
                    if (selectedRow != -1) {
                        // Get the data from the selected row
                        String studNum = (String) manage_request_data.getValueAt(selectedRow, 0);
                        String firstN = (String) manage_request_data.getValueAt(selectedRow, 1);
                        String lastN = (String) manage_request_data.getValueAt(selectedRow, 2);
                        String s_email = (String) manage_request_data.getValueAt(selectedRow, 3);
                        String b_acc_n = (String) manage_request_data.getValueAt(selectedRow, 4);
                        String b_title = (String) manage_request_data.getValueAt(selectedRow, 5);
                        String b_author = (String) manage_request_data.getValueAt(selectedRow, 6);
                        String b_category = (String) manage_request_data.getValueAt(selectedRow, 7);
                        String b_pubYear = (String) manage_request_data.getValueAt(selectedRow, 8);
                        String b_description = (String) manage_request_data.getValueAt(selectedRow, 9);
                        ImageIcon bookImageIcon = (ImageIcon) manage_request_data.getValueAt(selectedRow, 10);
                        ImageIcon studImageIcon = (ImageIcon) manage_request_data.getValueAt(selectedRow, 11);
                        Date studDateRequest = (Date) manage_request_data.getValueAt(selectedRow, 12);
                        
                        
                        
                       openRequest(studNum, firstN,  lastN,  s_email,  b_acc_n,
                               b_title,  b_author,  b_category,  b_pubYear,  b_description,  bookImageIcon,  studImageIcon, studDateRequest);
    
                    }
                }
            }
        });
         
         book_borrowers_data.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 1) {
                    // Get the selected row and column
                    int selectedRow = book_borrowers_data.getSelectedRow();
                    
                    // Ensure a valid row is selected
                    if (selectedRow != -1) {
                        // Get the data from the selected row
                        String studNum = (String) book_borrowers_data.getValueAt(selectedRow, 0);
                        String b_acc_n = (String) book_borrowers_data.getValueAt(selectedRow, 1);
                        String b_title = (String) book_borrowers_data.getValueAt(selectedRow, 2);
                        
                        Date DateRequestAccepted = (Date) book_borrowers_data.getValueAt(selectedRow, 6);
                        Date DateReturnDue = (Date) book_borrowers_data.getValueAt(selectedRow, 7);
                        int bookFeePenalty = (int) book_borrowers_data.getValueAt(selectedRow, 8);
                        
                        openBorrowDetails(studNum, b_acc_n, b_title,DateRequestAccepted, DateReturnDue, bookFeePenalty);
                        
                       
    
                    }
                }
            }
        });
          book_category_filter.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    
                    books_pub_filter.setSelectedIndex(-1);
                    book_available_filter.setSelectedIndex(-1);
                    searchTableBooks.setText("");

                    
                    String selectedCategory = (String) book_category_filter.getSelectedItem();
                    displayBooksByCategory(selectedCategory);
                }
            }
        });
          books_pub_filter.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    
                    book_category_filter.setSelectedIndex(-1);
                    book_available_filter.setSelectedIndex(-1);
                    searchTableBooks.setText("");

                   
                    String selectedPubYear = (String) books_pub_filter.getSelectedItem();
                    displayBooksPubYear(selectedPubYear);
                   
                }
            }
        });
          
         
        book_available_filter.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    // Clear items of other JComboBox components
                    
                    book_category_filter.setSelectedIndex(-1);
                    books_pub_filter.setSelectedIndex(-1);
                    searchTableBooks.setText("");
                    

                    String book_availble = (String) book_available_filter.getSelectedItem();
                    displayBooksAvailable(book_availble);
                }
            }
        });
        
        
    }
    private void openRequest(String studNum, String fn, String ln, 
            String Semail,String accN, String bk_title, String bk_author, String bk_category, 
            String bk_pubYear, String bk_description, ImageIcon bk_image, ImageIcon stud_image, Date requestDate) {
    // Create an instance of your popup_book_details frame
    send_email request_details = new send_email();
    
    // Set the book details in the new frame
    request_details.setRequestDetails(studNum, fn, ln, 
             Semail,  accN, bk_title, bk_author, bk_category, bk_pubYear, bk_description, bk_image, stud_image, requestDate);
    request_details.setVisible(true);
    
    // Set properties and make the frame visible
    
   
   
}
    private void openBorrowDetails(String studNum, String accN, String bk_title, Date DateRequested, Date returnDate, int bookPenaltyFee) {
    // Create an instance of your popup_book_details frame
    borrower_details bd = new borrower_details();
    
    // Set the book details in the new frame
    bd.setBorrowers(studNum, accN, bk_title, DateRequested, returnDate, bookPenaltyFee);
    bd.setVisible(true);
    
    // Set properties and make the frame visible
    
   
   
}
    private void BookDetailsAction(String accNo, String bookTitle, String bkTitle, String bkCategory, int bkAvailable, 
            String bkBorrow, String bkPubYear, String bkDescription, ImageIcon bkImage ) {
    // Create an instance of your popup_book_details frame
    view_action_books view_action_b = new view_action_books();
    
    // Set the book details in the new frame
    view_action_b.setBookActionDetails(accNo, bookTitle, bkTitle, bkCategory, bkAvailable, 
             bkBorrow, bkPubYear, bkDescription, bkImage );
    view_action_b.setVisible(true);
    
    // Set properties and make the frame visible
    
   
   
}
     Timer t ;
     SimpleDateFormat st ;
    public void times(){

   
    
  t = new Timer(0, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        Date dt  =new Date();
        st = new SimpleDateFormat("hh:mm:ss");
        
        String tt = st.format(dt);
        clock_feature.setText(tt);
        clock_feature.setHorizontalAlignment(SwingConstants.CENTER);
        
        }
    });
  
    t.start();
    
    

}
    public void dt(){

    Date d  =new Date();
    
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MMM-dd");
    
    String dd = sdf.format(d);
    home_date.setText(dd);
    home_date.setHorizontalAlignment(SwingConstants.CENTER);


}
    
    
    
/*
    home_panelB
    account_panelB
    manage_booksB
    manage_usersB
    */
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        side_bar_navigation = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        home_panelB = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        account_panelB = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        manage_booksB = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        manage_usersB = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        admin_logout = new javax.swing.JLabel();
        panel_containers = new javax.swing.JPanel();
        admin_home_panel = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel13 = new RoundedPanel(20);
        jLabel22 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        lib_announcement = new javax.swing.JTextArea();
        update_announce_bt = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        adminName = new javax.swing.JLabel();
        jPanel11 = new RoundedPanel(20);
        clock_feature = new javax.swing.JLabel();
        home_date = new javax.swing.JLabel();
        admin_account_panel = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        adminImage = new javax.swing.JLabel();
        jPanel14 = new RoundedPanel(25,Color.WHITE);
        jLabel19 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        admin_name_i = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        admin_sex_i = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        admin_email_i = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        admin_tel_i = new javax.swing.JLabel();
        jPanel15 = new RoundedPanel(25,Color.WHITE);
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        admin_issued_i = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        admin_status_lb = new javax.swing.JLabel();
        admin_id_number = new javax.swing.JLabel();
        manage_books_panel = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        mb = new RoundedPanel(20);
        jLabel10 = new javax.swing.JLabel();
        m_request = new RoundedPanel(20);
        jLabel24 = new javax.swing.JLabel();
        b_borrowers = new RoundedPanel(20);
        jLabel26 = new javax.swing.JLabel();
        conatiner_books = new javax.swing.JPanel();
        manage_books_panel_c = new javax.swing.JPanel();
        jLabel28 = new javax.swing.JLabel();
        jPanel5 = new RoundedPanel(25, Color.WHITE);
        jLabel35 = new javax.swing.JLabel();
        total_books = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        lms_books_table = new javax.swing.JTable();
        refresh_table = new RoundedPanel(20, Color.WHITE);
        jLabel39 = new javax.swing.JLabel();
        searchTableBooks = new javax.swing.JTextField();
        searchBt = new javax.swing.JButton();
        book_category_filter = new javax.swing.JComboBox<>();
        jLabel41 = new javax.swing.JLabel();
        books_pub_filter = new javax.swing.JComboBox<>();
        jLabel42 = new javax.swing.JLabel();
        book_available_filter = new javax.swing.JComboBox<>();
        jLabel45 = new javax.swing.JLabel();
        add_book_b = new RoundedPanel(20, Color.WHITE);
        jLabel36 = new javax.swing.JLabel();
        archived_book_bt = new RoundedPanel(20);
        jLabel37 = new javax.swing.JLabel();
        manage_request_panel = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        manage_request_data = new javax.swing.JTable();
        accepted_borrowers_panel = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        book_borrowers_data = new javax.swing.JTable();
        manage_users_panel = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        total_student_bt = new RoundedPanel(25);
        jLabel12 = new javax.swing.JLabel();
        total_student_p = new javax.swing.JLabel();
        tota_admin_bt = new RoundedPanel(25);
        jLabel13 = new javax.swing.JLabel();
        total_admin_p = new javax.swing.JLabel();
        add_user = new RoundedPanel(20,Color.WHITE);
        jLabel15 = new javax.swing.JLabel();
        update_user_bt = new RoundedPanel(20,Color.WHITE);
        jLabel16 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        actDeact_user = new RoundedPanel(20,Color.WHITE);
        jLabel17 = new javax.swing.JLabel();
        inactive_student_bt = new RoundedPanel(20);
        jLabel34 = new javax.swing.JLabel();
        student_inactive = new javax.swing.JLabel();
        active_student_bt = new RoundedPanel(20);
        jLabel40 = new javax.swing.JLabel();
        student_active = new javax.swing.JLabel();
        inactive_admin_bt = new RoundedPanel(20);
        admin_inactive = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        active_admin_bt = new RoundedPanel(20);
        admin_active = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        conatine_of_tables = new javax.swing.JPanel();
        total_admin_data = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        total_admin_tb1 = new javax.swing.JTable();
        active_admin_data = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        active_admin_tb2 = new javax.swing.JTable();
        inactive_admin_data = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        inactive_admin_tb3 = new javax.swing.JTable();
        total_student_data = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        total_student_tb1 = new javax.swing.JTable();
        active_student_data = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        active_student_tb2 = new javax.swing.JTable();
        inactive_student_data = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        inactive_student_tb3 = new javax.swing.JTable();
        jPanel7 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        side_bar_navigation.setBackground(new java.awt.Color(109, 139, 116));
        side_bar_navigation.setPreferredSize(new java.awt.Dimension(200, 600));
        side_bar_navigation.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(85, 96, 82));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("ADMIN DASHBOARD");

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/udm-seal_70px.png"))); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel7)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(66, 66, 66)
                .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(64, 64, 64))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, 86, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        side_bar_navigation.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 200, 140));

        home_panelB.setBackground(new java.awt.Color(182, 196, 182));
        home_panelB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                home_panelBMouseClicked(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/home.png"))); // NOI18N
        jLabel2.setText("Home");

        javax.swing.GroupLayout home_panelBLayout = new javax.swing.GroupLayout(home_panelB);
        home_panelB.setLayout(home_panelBLayout);
        home_panelBLayout.setHorizontalGroup(
            home_panelBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(home_panelBLayout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(jLabel2)
                .addContainerGap(87, Short.MAX_VALUE))
        );
        home_panelBLayout.setVerticalGroup(
            home_panelBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
        );

        side_bar_navigation.add(home_panelB, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 167, 200, -1));

        account_panelB.setBackground(new java.awt.Color(109, 139, 116));
        account_panelB.setPreferredSize(new java.awt.Dimension(200, 54));
        account_panelB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                account_panelBMouseClicked(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/user.png"))); // NOI18N
        jLabel1.setText("Account");

        javax.swing.GroupLayout account_panelBLayout = new javax.swing.GroupLayout(account_panelB);
        account_panelB.setLayout(account_panelBLayout);
        account_panelBLayout.setHorizontalGroup(
            account_panelBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(account_panelBLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jLabel1)
                .addContainerGap(78, Short.MAX_VALUE))
        );
        account_panelBLayout.setVerticalGroup(
            account_panelBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        side_bar_navigation.add(account_panelB, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 200, 50));

        manage_booksB.setBackground(new java.awt.Color(109, 139, 116));
        manage_booksB.setPreferredSize(new java.awt.Dimension(200, 54));
        manage_booksB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                manage_booksBMouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/books.png"))); // NOI18N
        jLabel3.setText("Manage Books");

        javax.swing.GroupLayout manage_booksBLayout = new javax.swing.GroupLayout(manage_booksB);
        manage_booksB.setLayout(manage_booksBLayout);
        manage_booksBLayout.setHorizontalGroup(
            manage_booksBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(manage_booksBLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jLabel3)
                .addContainerGap(46, Short.MAX_VALUE))
        );
        manage_booksBLayout.setVerticalGroup(
            manage_booksBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        side_bar_navigation.add(manage_booksB, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 310, 200, 50));

        manage_usersB.setBackground(new java.awt.Color(109, 139, 116));
        manage_usersB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                manage_usersBMouseClicked(evt);
            }
        });

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/group.png"))); // NOI18N
        jLabel4.setText("Manage Users");

        javax.swing.GroupLayout manage_usersBLayout = new javax.swing.GroupLayout(manage_usersB);
        manage_usersB.setLayout(manage_usersBLayout);
        manage_usersBLayout.setHorizontalGroup(
            manage_usersBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(manage_usersBLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jLabel4)
                .addContainerGap(49, Short.MAX_VALUE))
        );
        manage_usersBLayout.setVerticalGroup(
            manage_usersBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        side_bar_navigation.add(manage_usersB, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 380, 200, 50));

        jPanel10.setBackground(new java.awt.Color(109, 139, 116));

        admin_logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/logout.png"))); // NOI18N
        admin_logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                admin_logoutMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(admin_logout)
                .addContainerGap(162, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(admin_logout, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        side_bar_navigation.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 680, 200, 50));

        getContentPane().add(side_bar_navigation, java.awt.BorderLayout.LINE_START);

        panel_containers.setBackground(new java.awt.Color(255, 255, 255));
        panel_containers.setLayout(new java.awt.CardLayout());

        admin_home_panel.setBackground(new java.awt.Color(182, 196, 182));

        jPanel1.setBackground(new java.awt.Color(115, 144, 114));

        jLabel8.setText("HOME");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel8)
                .addContainerGap(1171, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel8)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jLabel22.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel22.setText("                               LIBRARY ANNOUNCEMENT");

        lib_announcement.setColumns(20);
        lib_announcement.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lib_announcement.setLineWrap(true);
        lib_announcement.setRows(5);
        lib_announcement.setWrapStyleWord(true);
        jScrollPane8.setViewportView(lib_announcement);

        update_announce_bt.setText("Update");
        update_announce_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_announce_btActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jScrollPane8)
                .addGap(35, 35, 35))
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(213, 213, 213)
                .addComponent(update_announce_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, 513, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(update_announce_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel18.setText("GOOD DAY ADMIN ");

        adminName.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        adminName.setText("[ADMIN NAME]");

        clock_feature.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        clock_feature.setText("12:30");

        home_date.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        home_date.setText("date");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(clock_feature, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
            .addComponent(home_date, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addComponent(clock_feature, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(home_date)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout admin_home_panelLayout = new javax.swing.GroupLayout(admin_home_panel);
        admin_home_panel.setLayout(admin_home_panelLayout);
        admin_home_panelLayout.setHorizontalGroup(
            admin_home_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(admin_home_panelLayout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(admin_home_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(admin_home_panelLayout.createSequentialGroup()
                        .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(admin_home_panelLayout.createSequentialGroup()
                        .addComponent(jLabel18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(adminName))))
        );
        admin_home_panelLayout.setVerticalGroup(
            admin_home_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(admin_home_panelLayout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(admin_home_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(adminName))
                .addGap(54, 54, 54)
                .addGroup(admin_home_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(271, Short.MAX_VALUE))
        );

        panel_containers.add(admin_home_panel, "card2");

        admin_account_panel.setBackground(new java.awt.Color(182, 196, 182));

        jPanel4.setBackground(new java.awt.Color(115, 144, 114));

        jLabel9.setText("ACCOUNT");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel9)
                .addContainerGap(1151, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addGap(14, 14, 14))
        );

        adminImage.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jPanel14.setBackground(new java.awt.Color(255, 255, 255));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel19.setText("ADMIN INFORMATION");

        jLabel23.setText("NAME:");

        admin_name_i.setText("[ADMIN NAME]");

        jLabel25.setText("SEX:");

        admin_sex_i.setText("[SEX]");

        jLabel27.setText("EMAIL:");

        admin_email_i.setText("[EMAIL]");

        jLabel29.setText("TEL NO:");

        admin_tel_i.setText("[TELEPHONE NUMBER]");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel23)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(admin_name_i))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGap(144, 144, 144)
                        .addComponent(jLabel19))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel25)
                        .addGap(18, 18, 18)
                        .addComponent(admin_sex_i))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel29)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(admin_tel_i))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel27)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(admin_email_i)))
                .addContainerGap(156, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel19)
                .addGap(28, 28, 28)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(admin_name_i))
                .addGap(26, 26, 26)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(admin_sex_i))
                .addGap(26, 26, 26)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(admin_email_i))
                .addGap(28, 28, 28)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(admin_tel_i))
                .addContainerGap(100, Short.MAX_VALUE))
        );

        jPanel15.setBackground(new java.awt.Color(255, 255, 255));

        jLabel31.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel31.setText("ADMIN STATUS");

        jLabel32.setText("ISSUED DATE:");

        admin_issued_i.setText("[ISSUED DATE]");

        jLabel46.setText("STATUS:");

        admin_status_lb.setText("[STATS]");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                .addContainerGap(122, Short.MAX_VALUE)
                .addComponent(jLabel31)
                .addGap(120, 120, 120))
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(jLabel32)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(admin_issued_i))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(jLabel46)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(admin_status_lb)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel31)
                .addGap(26, 26, 26)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(admin_issued_i))
                .addGap(26, 26, 26)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel46)
                    .addComponent(admin_status_lb))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        admin_id_number.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        admin_id_number.setText("    21-17-045");
        admin_id_number.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout admin_account_panelLayout = new javax.swing.GroupLayout(admin_account_panel);
        admin_account_panel.setLayout(admin_account_panelLayout);
        admin_account_panelLayout.setHorizontalGroup(
            admin_account_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(admin_account_panelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(admin_account_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(adminImage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(admin_id_number, javax.swing.GroupLayout.DEFAULT_SIZE, 98, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        admin_account_panelLayout.setVerticalGroup(
            admin_account_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(admin_account_panelLayout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(admin_account_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(admin_account_panelLayout.createSequentialGroup()
                        .addComponent(adminImage, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(admin_id_number, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(543, Short.MAX_VALUE))
        );

        panel_containers.add(admin_account_panel, "card3");

        manage_books_panel.setBackground(new java.awt.Color(182, 196, 182));
        manage_books_panel.setLayout(new java.awt.BorderLayout());

        jPanel16.setBackground(new java.awt.Color(182, 196, 182));

        jPanel17.setBackground(new java.awt.Color(109, 139, 116));

        jLabel6.setText("MANAGE BOOKS");

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel6)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        mb.setBackground(new java.awt.Color(255, 255, 255));
        mb.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mbMouseClicked(evt);
            }
        });

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/read.png"))); // NOI18N
        jLabel10.setText("Manage Books");

        javax.swing.GroupLayout mbLayout = new javax.swing.GroupLayout(mb);
        mb.setLayout(mbLayout);
        mbLayout.setHorizontalGroup(
            mbLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mbLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        mbLayout.setVerticalGroup(
            mbLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        m_request.setBackground(new java.awt.Color(109, 139, 116));
        m_request.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                m_requestMouseClicked(evt);
            }
        });

        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/code-pull-request.png"))); // NOI18N
        jLabel24.setText("Manage Request");

        javax.swing.GroupLayout m_requestLayout = new javax.swing.GroupLayout(m_request);
        m_request.setLayout(m_requestLayout);
        m_requestLayout.setHorizontalGroup(
            m_requestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, m_requestLayout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addComponent(jLabel24)
                .addGap(16, 16, 16))
        );
        m_requestLayout.setVerticalGroup(
            m_requestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel24, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        b_borrowers.setBackground(new java.awt.Color(109, 139, 116));
        b_borrowers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                b_borrowersMouseClicked(evt);
            }
        });

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/list.png"))); // NOI18N
        jLabel26.setText("Borrowers");

        javax.swing.GroupLayout b_borrowersLayout = new javax.swing.GroupLayout(b_borrowers);
        b_borrowers.setLayout(b_borrowersLayout);
        b_borrowersLayout.setHorizontalGroup(
            b_borrowersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(b_borrowersLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel26)
                .addContainerGap(18, Short.MAX_VALUE))
        );
        b_borrowersLayout.setVerticalGroup(
            b_borrowersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel26, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(mb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(m_request, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(b_borrowers, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(182, 784, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(m_request, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(b_borrowers, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        manage_books_panel.add(jPanel16, java.awt.BorderLayout.PAGE_START);

        conatiner_books.setBackground(new java.awt.Color(182, 196, 182));
        conatiner_books.setLayout(new java.awt.CardLayout());

        manage_books_panel_c.setBackground(new java.awt.Color(182, 196, 182));

        jLabel28.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel28.setText("MANAGE BOOKS");

        jLabel35.setText("TOTAL BOOKS");

        total_books.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        total_books.setText("TOTAL");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jLabel35)
                .addContainerGap(50, Short.MAX_VALUE))
            .addComponent(total_books, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(total_books, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jLabel35)
                .addContainerGap())
        );

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 255));

        lms_books_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ACC NO", "TITLE", "AUTHOR", "CATEGORY", "BOOK AVAILABLE", "BOOK BORROW", "PUBLICATION YEAR", "DESCRIPTION", "IMAGE"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(lms_books_table);

        refresh_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                refresh_tableMouseClicked(evt);
            }
        });

        jLabel39.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/refresh.png"))); // NOI18N

        javax.swing.GroupLayout refresh_tableLayout = new javax.swing.GroupLayout(refresh_table);
        refresh_table.setLayout(refresh_tableLayout);
        refresh_tableLayout.setHorizontalGroup(
            refresh_tableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(refresh_tableLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel39)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        refresh_tableLayout.setVerticalGroup(
            refresh_tableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel39, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
        );

        searchBt.setText("Search");
        searchBt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBtActionPerformed(evt);
            }
        });

        book_category_filter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "Business", "Education", "Environment", "Information and Publishing", "Law", "Literature", "Medicine", "Nation and World", "Religion", "Science", "Social Science", "Technology", "Engineering", "Mathematics" }));

        jLabel41.setText("Category");

        books_pub_filter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] {"", "2023", "2022", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995"}));

        jLabel42.setText("Pub. Year");

        book_available_filter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "1", "0" }));

        jLabel45.setText("Book Available");

        add_book_b.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                add_book_bMouseClicked(evt);
            }
        });

        jLabel36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/add_book.png"))); // NOI18N

        javax.swing.GroupLayout add_book_bLayout = new javax.swing.GroupLayout(add_book_b);
        add_book_b.setLayout(add_book_bLayout);
        add_book_bLayout.setHorizontalGroup(
            add_book_bLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(add_book_bLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel36, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(21, 21, 21))
        );
        add_book_bLayout.setVerticalGroup(
            add_book_bLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel36, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
        );

        archived_book_bt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                archived_book_btMouseClicked(evt);
            }
        });

        jLabel37.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/archive.png"))); // NOI18N
        jLabel37.setText("ARCHIVED");

        javax.swing.GroupLayout archived_book_btLayout = new javax.swing.GroupLayout(archived_book_bt);
        archived_book_bt.setLayout(archived_book_btLayout);
        archived_book_btLayout.setHorizontalGroup(
            archived_book_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(archived_book_btLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel37, javax.swing.GroupLayout.DEFAULT_SIZE, 103, Short.MAX_VALUE)
                .addContainerGap())
        );
        archived_book_btLayout.setVerticalGroup(
            archived_book_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout manage_books_panel_cLayout = new javax.swing.GroupLayout(manage_books_panel_c);
        manage_books_panel_c.setLayout(manage_books_panel_cLayout);
        manage_books_panel_cLayout.setHorizontalGroup(
            manage_books_panel_cLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(manage_books_panel_cLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(manage_books_panel_cLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(manage_books_panel_cLayout.createSequentialGroup()
                        .addGroup(manage_books_panel_cLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel28))
                        .addGroup(manage_books_panel_cLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(manage_books_panel_cLayout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addComponent(refresh_table, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(searchTableBooks, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(searchBt)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel41)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(book_category_filter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel42)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(books_pub_filter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel45)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(book_available_filter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, manage_books_panel_cLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(add_book_b, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(archived_book_bt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1172, Short.MAX_VALUE))
                .addGap(43, 43, 43))
        );
        manage_books_panel_cLayout.setVerticalGroup(
            manage_books_panel_cLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(manage_books_panel_cLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(manage_books_panel_cLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(manage_books_panel_cLayout.createSequentialGroup()
                        .addComponent(jLabel28)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(manage_books_panel_cLayout.createSequentialGroup()
                        .addGroup(manage_books_panel_cLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(add_book_b, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(archived_book_bt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(manage_books_panel_cLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(refresh_table, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(manage_books_panel_cLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(searchBt, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(searchTableBooks, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(book_category_filter, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel41)
                                .addComponent(books_pub_filter, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel42)
                                .addComponent(book_available_filter, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel45)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 598, Short.MAX_VALUE)
                .addGap(41, 41, 41))
        );

        conatiner_books.add(manage_books_panel_c, "card2");

        manage_request_panel.setBackground(new java.awt.Color(182, 196, 182));

        jLabel30.setText("MANAGE REQUEST");

        manage_request_data.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STUDENT NO.", "FIRST NAME", "LAST NAME", "EMAIL", "ACC NO.", "BOOK TO BORROW", "AUTHOR", "CATEGORY", "PUBLICATION YEAR", "DESCRIPTION", "BOOK IMAGE", "STUDENT IMAGE", "DATE REQUESTED"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane9.setViewportView(manage_request_data);

        javax.swing.GroupLayout manage_request_panelLayout = new javax.swing.GroupLayout(manage_request_panel);
        manage_request_panel.setLayout(manage_request_panelLayout);
        manage_request_panelLayout.setHorizontalGroup(
            manage_request_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(manage_request_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(manage_request_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel30)
                    .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 1116, Short.MAX_VALUE))
                .addGap(99, 99, 99))
        );
        manage_request_panelLayout.setVerticalGroup(
            manage_request_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(manage_request_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel30)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 686, Short.MAX_VALUE)
                .addGap(60, 60, 60))
        );

        conatiner_books.add(manage_request_panel, "card3");

        accepted_borrowers_panel.setBackground(new java.awt.Color(182, 196, 182));

        jLabel33.setText("ACCEPTED BORROWERS");

        book_borrowers_data.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STUDENT ID", "ACC NO.", "TITLE", "AUTHOR", "CATEGORY", "PUBLICATION YEAR", "DATE ACCEPTED", "RETURN DUE DATE", "BOOK FEE PENALTY"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane10.setViewportView(book_borrowers_data);

        javax.swing.GroupLayout accepted_borrowers_panelLayout = new javax.swing.GroupLayout(accepted_borrowers_panel);
        accepted_borrowers_panel.setLayout(accepted_borrowers_panelLayout);
        accepted_borrowers_panelLayout.setHorizontalGroup(
            accepted_borrowers_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(accepted_borrowers_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(accepted_borrowers_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel33)
                    .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 1128, Short.MAX_VALUE))
                .addContainerGap(87, Short.MAX_VALUE))
        );
        accepted_borrowers_panelLayout.setVerticalGroup(
            accepted_borrowers_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(accepted_borrowers_panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel33)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 647, Short.MAX_VALUE)
                .addContainerGap(99, Short.MAX_VALUE))
        );

        conatiner_books.add(accepted_borrowers_panel, "card4");

        manage_books_panel.add(conatiner_books, java.awt.BorderLayout.CENTER);

        panel_containers.add(manage_books_panel, "card4");

        manage_users_panel.setBackground(new java.awt.Color(182, 196, 182));

        jPanel6.setBackground(new java.awt.Color(115, 144, 114));

        jLabel11.setText("MANAGE USERS");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel11)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addComponent(jLabel11)
                .addGap(16, 16, 16))
        );

        total_student_bt.setBackground(new java.awt.Color(109, 139, 116));
        total_student_bt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                total_student_btMouseClicked(evt);
            }
        });

        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("TOTAL STUDENTS");

        total_student_p.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        total_student_p.setForeground(new java.awt.Color(255, 255, 255));
        total_student_p.setText("TOTAL");

        javax.swing.GroupLayout total_student_btLayout = new javax.swing.GroupLayout(total_student_bt);
        total_student_bt.setLayout(total_student_btLayout);
        total_student_btLayout.setHorizontalGroup(
            total_student_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(total_student_btLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel12)
                .addContainerGap(35, Short.MAX_VALUE))
            .addComponent(total_student_p, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        total_student_btLayout.setVerticalGroup(
            total_student_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, total_student_btLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(total_student_p, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jLabel12)
                .addGap(14, 14, 14))
        );

        tota_admin_bt.setBackground(new java.awt.Color(255, 255, 255));
        tota_admin_bt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tota_admin_btMouseClicked(evt);
            }
        });

        jLabel13.setText("TOTAL ADMIN");

        total_admin_p.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        total_admin_p.setText("TOTAL");

        javax.swing.GroupLayout tota_admin_btLayout = new javax.swing.GroupLayout(tota_admin_bt);
        tota_admin_bt.setLayout(tota_admin_btLayout);
        tota_admin_btLayout.setHorizontalGroup(
            tota_admin_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tota_admin_btLayout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(jLabel13)
                .addContainerGap(36, Short.MAX_VALUE))
            .addComponent(total_admin_p, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        tota_admin_btLayout.setVerticalGroup(
            tota_admin_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tota_admin_btLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(total_admin_p, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel13)
                .addGap(16, 16, 16))
        );

        add_user.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                add_userMouseClicked(evt);
            }
        });

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/add-user.png"))); // NOI18N

        javax.swing.GroupLayout add_userLayout = new javax.swing.GroupLayout(add_user);
        add_user.setLayout(add_userLayout);
        add_userLayout.setHorizontalGroup(
            add_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, add_userLayout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );
        add_userLayout.setVerticalGroup(
            add_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
        );

        update_user_bt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                update_user_btMouseClicked(evt);
            }
        });

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/update.png"))); // NOI18N

        javax.swing.GroupLayout update_user_btLayout = new javax.swing.GroupLayout(update_user_bt);
        update_user_bt.setLayout(update_user_btLayout);
        update_user_btLayout.setHorizontalGroup(
            update_user_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(update_user_btLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabel16)
                .addContainerGap(32, Short.MAX_VALUE))
        );
        update_user_btLayout.setVerticalGroup(
            update_user_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, update_user_btLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel16)
                .addContainerGap())
        );

        actDeact_user.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                actDeact_userMouseClicked(evt);
            }
        });

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lms_images/switch.png"))); // NOI18N

        javax.swing.GroupLayout actDeact_userLayout = new javax.swing.GroupLayout(actDeact_user);
        actDeact_user.setLayout(actDeact_userLayout);
        actDeact_userLayout.setHorizontalGroup(
            actDeact_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, actDeact_userLayout.createSequentialGroup()
                .addContainerGap(35, Short.MAX_VALUE)
                .addComponent(jLabel17)
                .addGap(33, 33, 33))
        );
        actDeact_userLayout.setVerticalGroup(
            actDeact_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel17, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
        );

        inactive_student_bt.setBackground(new java.awt.Color(109, 139, 116));
        inactive_student_bt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                inactive_student_btMouseClicked(evt);
            }
        });

        jLabel34.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("    INACTIVE");

        student_inactive.setBackground(new java.awt.Color(255, 255, 255));
        student_inactive.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        student_inactive.setForeground(new java.awt.Color(255, 255, 255));
        student_inactive.setText("0");

        javax.swing.GroupLayout inactive_student_btLayout = new javax.swing.GroupLayout(inactive_student_bt);
        inactive_student_bt.setLayout(inactive_student_btLayout);
        inactive_student_btLayout.setHorizontalGroup(
            inactive_student_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(student_inactive, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel34, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
        );
        inactive_student_btLayout.setVerticalGroup(
            inactive_student_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inactive_student_btLayout.createSequentialGroup()
                .addComponent(student_inactive, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel34)
                .addContainerGap())
        );

        active_student_bt.setBackground(new java.awt.Color(109, 139, 116));
        active_student_bt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                active_student_btMouseClicked(evt);
            }
        });

        jLabel40.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("      ACTIVE");

        student_active.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        student_active.setForeground(new java.awt.Color(255, 255, 255));
        student_active.setText("0");

        javax.swing.GroupLayout active_student_btLayout = new javax.swing.GroupLayout(active_student_bt);
        active_student_bt.setLayout(active_student_btLayout);
        active_student_btLayout.setHorizontalGroup(
            active_student_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(student_active, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel40, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        active_student_btLayout.setVerticalGroup(
            active_student_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, active_student_btLayout.createSequentialGroup()
                .addComponent(student_active, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        inactive_admin_bt.setBackground(new java.awt.Color(109, 139, 116));
        inactive_admin_bt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                inactive_admin_btMouseClicked(evt);
            }
        });

        admin_inactive.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        admin_inactive.setForeground(new java.awt.Color(255, 255, 255));
        admin_inactive.setText("0");

        jLabel44.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(255, 255, 255));
        jLabel44.setText("     INACTIVE");

        javax.swing.GroupLayout inactive_admin_btLayout = new javax.swing.GroupLayout(inactive_admin_bt);
        inactive_admin_bt.setLayout(inactive_admin_btLayout);
        inactive_admin_btLayout.setHorizontalGroup(
            inactive_admin_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel44, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
            .addComponent(admin_inactive, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        inactive_admin_btLayout.setVerticalGroup(
            inactive_admin_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inactive_admin_btLayout.createSequentialGroup()
                .addComponent(admin_inactive)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel44)
                .addContainerGap())
        );

        active_admin_bt.setBackground(new java.awt.Color(109, 139, 116));
        active_admin_bt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                active_admin_btMouseClicked(evt);
            }
        });

        admin_active.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        admin_active.setForeground(new java.awt.Color(255, 255, 255));
        admin_active.setText("0");

        jLabel43.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(255, 255, 255));
        jLabel43.setText("      ACTIVE");

        javax.swing.GroupLayout active_admin_btLayout = new javax.swing.GroupLayout(active_admin_bt);
        active_admin_bt.setLayout(active_admin_btLayout);
        active_admin_btLayout.setHorizontalGroup(
            active_admin_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(admin_active, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel43, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
        );
        active_admin_btLayout.setVerticalGroup(
            active_admin_btLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(active_admin_btLayout.createSequentialGroup()
                .addComponent(admin_active, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel43))
        );

        conatine_of_tables.setBackground(new java.awt.Color(255, 153, 153));
        conatine_of_tables.setLayout(new java.awt.CardLayout());

        total_admin_data.setBackground(new java.awt.Color(182, 196, 182));

        total_admin_tb1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ADMIN ID", "FIRST NAME", "LAST NAME", "SEX", "EMAIL", "TELEPHONE NO.", "ISSUED DATE", "STATUS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(total_admin_tb1);

        javax.swing.GroupLayout total_admin_dataLayout = new javax.swing.GroupLayout(total_admin_data);
        total_admin_data.setLayout(total_admin_dataLayout);
        total_admin_dataLayout.setHorizontalGroup(
            total_admin_dataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, total_admin_dataLayout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1185, Short.MAX_VALUE)
                .addContainerGap())
        );
        total_admin_dataLayout.setVerticalGroup(
            total_admin_dataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(total_admin_dataLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 552, Short.MAX_VALUE)
                .addContainerGap())
        );

        conatine_of_tables.add(total_admin_data, "card2");

        active_admin_data.setBackground(new java.awt.Color(182, 196, 182));

        active_admin_tb2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ADMIN ID", "FIRST NAME", "LAST NAME", "SEX", "EMAIL", "TELEPHONE NO.", "ISSUED DATE", "STATUS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(active_admin_tb2);

        javax.swing.GroupLayout active_admin_dataLayout = new javax.swing.GroupLayout(active_admin_data);
        active_admin_data.setLayout(active_admin_dataLayout);
        active_admin_dataLayout.setHorizontalGroup(
            active_admin_dataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, active_admin_dataLayout.createSequentialGroup()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 1185, Short.MAX_VALUE)
                .addContainerGap())
        );
        active_admin_dataLayout.setVerticalGroup(
            active_admin_dataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(active_admin_dataLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 552, Short.MAX_VALUE)
                .addContainerGap())
        );

        conatine_of_tables.add(active_admin_data, "card3");

        inactive_admin_data.setBackground(new java.awt.Color(182, 196, 182));

        inactive_admin_tb3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ADMIN ID", "FIRST NAME", "LAST NAME", "SEX", "EMAIL", "TELEPHONE NO.", "ISSUED DATE", "STATUS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(inactive_admin_tb3);

        javax.swing.GroupLayout inactive_admin_dataLayout = new javax.swing.GroupLayout(inactive_admin_data);
        inactive_admin_data.setLayout(inactive_admin_dataLayout);
        inactive_admin_dataLayout.setHorizontalGroup(
            inactive_admin_dataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inactive_admin_dataLayout.createSequentialGroup()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 1185, Short.MAX_VALUE)
                .addContainerGap())
        );
        inactive_admin_dataLayout.setVerticalGroup(
            inactive_admin_dataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inactive_admin_dataLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 552, Short.MAX_VALUE)
                .addContainerGap())
        );

        conatine_of_tables.add(inactive_admin_data, "card4");

        total_student_data.setBackground(new java.awt.Color(182, 196, 182));

        total_student_tb1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STUDENT NO.", "FIRST NAME", "LAST NAME", "AGE", "SEX", "EMAIL", "ADDRESS", "TEL NO.", "YEAR", "COURSE", "SECTION", "ISSUED DATE", "STATUS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane5.setViewportView(total_student_tb1);

        javax.swing.GroupLayout total_student_dataLayout = new javax.swing.GroupLayout(total_student_data);
        total_student_data.setLayout(total_student_dataLayout);
        total_student_dataLayout.setHorizontalGroup(
            total_student_dataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(total_student_dataLayout.createSequentialGroup()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 1185, Short.MAX_VALUE)
                .addContainerGap())
        );
        total_student_dataLayout.setVerticalGroup(
            total_student_dataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(total_student_dataLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 552, Short.MAX_VALUE)
                .addContainerGap())
        );

        conatine_of_tables.add(total_student_data, "card5");

        active_student_data.setBackground(new java.awt.Color(182, 196, 182));

        active_student_tb2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STUDENT NO.", "FIRST NAME", "LAST NAME", "AGE", "SEX", "EMAIL", "ADDRESS", "TEL NO.", "YEAR", "COURSE", "SECTION", "ISSUED DATE", "STATUS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane6.setViewportView(active_student_tb2);

        javax.swing.GroupLayout active_student_dataLayout = new javax.swing.GroupLayout(active_student_data);
        active_student_data.setLayout(active_student_dataLayout);
        active_student_dataLayout.setHorizontalGroup(
            active_student_dataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(active_student_dataLayout.createSequentialGroup()
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 1185, Short.MAX_VALUE)
                .addContainerGap())
        );
        active_student_dataLayout.setVerticalGroup(
            active_student_dataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(active_student_dataLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 552, Short.MAX_VALUE)
                .addContainerGap())
        );

        conatine_of_tables.add(active_student_data, "card6");

        inactive_student_data.setBackground(new java.awt.Color(182, 196, 182));

        inactive_student_tb3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STUDENT NO.", "FIRST NAME", "LAST NAME", "AGE", "SEX", "EMAIL", "ADDRESS", "TEL NO.", "YEAR", "COURSE", "SECTION", "ISSUED DATE", "STATUS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane7.setViewportView(inactive_student_tb3);

        javax.swing.GroupLayout inactive_student_dataLayout = new javax.swing.GroupLayout(inactive_student_data);
        inactive_student_data.setLayout(inactive_student_dataLayout);
        inactive_student_dataLayout.setHorizontalGroup(
            inactive_student_dataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inactive_student_dataLayout.createSequentialGroup()
                .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 1185, Short.MAX_VALUE)
                .addContainerGap())
        );
        inactive_student_dataLayout.setVerticalGroup(
            inactive_student_dataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inactive_student_dataLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 552, Short.MAX_VALUE)
                .addContainerGap())
        );

        conatine_of_tables.add(inactive_student_data, "card7");

        jPanel7.setBackground(new java.awt.Color(0, 102, 102));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1191, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 564, Short.MAX_VALUE)
        );

        conatine_of_tables.add(jPanel7, "card8");

        javax.swing.GroupLayout manage_users_panelLayout = new javax.swing.GroupLayout(manage_users_panel);
        manage_users_panel.setLayout(manage_users_panelLayout);
        manage_users_panelLayout.setHorizontalGroup(
            manage_users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(manage_users_panelLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(manage_users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(manage_users_panelLayout.createSequentialGroup()
                        .addComponent(total_student_bt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(manage_users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(active_student_bt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(inactive_student_bt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(80, 80, 80)
                        .addComponent(tota_admin_bt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(manage_users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(inactive_admin_bt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(active_admin_bt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(add_user, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(update_user_bt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(actDeact_user, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(manage_users_panelLayout.createSequentialGroup()
                        .addComponent(conatine_of_tables, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                        .addComponent(jLabel14)))
                .addContainerGap())
        );
        manage_users_panelLayout.setVerticalGroup(
            manage_users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(manage_users_panelLayout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(manage_users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(add_user, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(manage_users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, manage_users_panelLayout.createSequentialGroup()
                            .addComponent(active_admin_bt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(inactive_admin_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addComponent(tota_admin_bt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(manage_users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, manage_users_panelLayout.createSequentialGroup()
                            .addComponent(active_student_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(inactive_student_bt, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addComponent(total_student_bt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(manage_users_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(update_user_bt, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(actDeact_user, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(20, 20, 20)
                .addComponent(conatine_of_tables, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel14)
                .addGap(151, 151, 151))
        );

        panel_containers.add(manage_users_panel, "card5");

        getContentPane().add(panel_containers, java.awt.BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    public static void countRowsAndUpdateLabel() {
        String jdbcUrl = "jdbc:h2:~/test";
        String username = "sa";
        String password = "glen";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
            String query = "SELECT COUNT(*) FROM ADMIN";
            try (PreparedStatement statement = connection.prepareStatement(query);
                 ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int rowCount = resultSet.getInt(1);
                    total_admin_p.setHorizontalAlignment(SwingConstants.CENTER);
                    total_admin_p.setText(""+rowCount);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    public static void countAdminsActive() {
    String jdbcUrl = "jdbc:h2:~/test";
    String username = "sa";
    String password = "glen";

    try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
        String query = "SELECT COUNT(*) FROM ADMIN WHERE status = 1";
        try (PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                int rowCount = resultSet.getInt(1);
                // Assuming total_admin_p is a Swing component to display the count
                admin_active.setHorizontalAlignment(SwingConstants.CENTER);
                admin_active.setText("" + rowCount);
            }
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
}
    public static void countAdminsInactive() {
    String jdbcUrl = "jdbc:h2:~/test";
    String username = "sa";
    String password = "glen";

    try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
        String query = "SELECT COUNT(*) FROM ADMIN WHERE status = 0";
        try (PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                int rowCount = resultSet.getInt(1);
                // Assuming total_admin_p is a Swing component to display the count
                admin_inactive.setHorizontalAlignment(SwingConstants.CENTER);
                admin_inactive.setText("" + rowCount);
            }
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
}

    
    public static void countStudent() {
        String jdbcUrl = "jdbc:h2:~/test";
        String username = "sa";
        String password = "glen";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
            String query = "SELECT COUNT(*) FROM LMSTUDENTS";
            try (PreparedStatement statement = connection.prepareStatement(query);
                 ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int rowCount = resultSet.getInt(1);
                    total_student_p.setHorizontalAlignment(SwingConstants.CENTER);
                    total_student_p.setText(""+rowCount);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    public static void countStudentActive() {
    String jdbcUrl = "jdbc:h2:~/test";
    String username = "sa";
    String password = "glen";

    try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
        String query = "SELECT COUNT(*) FROM LMSTUDENTS WHERE status = 1";
        try (PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                int rowCount = resultSet.getInt(1);
                // Assuming total_admin_p is a Swing component to display the count
                student_active.setHorizontalAlignment(SwingConstants.CENTER);
                student_active.setText("" + rowCount);
            }
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
}
    public static void countStudentInactive() {
    String jdbcUrl = "jdbc:h2:~/test";
    String username = "sa";
    String password = "glen";

    try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
        String query = "SELECT COUNT(*) FROM LMSTUDENTS WHERE status = 0";
        try (PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                int rowCount = resultSet.getInt(1);
                // Assuming total_admin_p is a Swing component to display the count
                student_inactive.setHorizontalAlignment(SwingConstants.CENTER);
                student_inactive.setText("" + rowCount);
            }
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
}
    
    
    public static void countBooks() {
        String jdbcUrl = "jdbc:h2:~/test";
        String username = "sa";
        String password = "glen";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
            String query = "SELECT COUNT(*) FROM LIBRARY_BOOKS WHERE book_status = 1";
            try (PreparedStatement statement = connection.prepareStatement(query);
                 ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int rowCount = resultSet.getInt(1);
                    total_books.setHorizontalAlignment(SwingConstants.CENTER);
                    total_books.setText(""+rowCount);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    public void setAdminDetails(Object[] adminDetails) throws SQLException {
        
    String firstName = (String) adminDetails[0];
    String lastName = (String) adminDetails[1];
    byte[] adminImageBytes = (byte[]) adminDetails[2];
    String admin_Id = (String) adminDetails[3];
    String admin_email = (String) adminDetails[4];
    String admin_sex = (String) adminDetails[5];
    String admin_tel = (String) adminDetails[6];
    Date   admin_issued_date = (Date) adminDetails[7];
    int adminStatus = (int)  adminDetails[8];
    String admin_sts = (adminStatus == 1)? "ACTIVE" : "INACTIVE";
    //String admin_issued_by = (String) adminDetails[8];
    

    // Set the first name and last name labels
    adminName.setText((firstName + " " + lastName + "!").toUpperCase());

    // Convert the byte array to ImageIcon and set it in adminImage label
    ImageIcon adminImageIcon = createImageIcon(adminImageBytes);
    adminImage.setIcon(adminImageIcon);
    
    admin_id_number.setText("    "+admin_Id);
    admin_sex_i.setText((admin_sex).toUpperCase());
    admin_email_i.setText(admin_email);
    admin_tel_i.setText(admin_tel);
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    admin_issued_i.setText(dateFormat.format(admin_issued_date));
    //admin_issued_by_i.setText((admin_issued_by).toUpperCase());
    admin_name_i.setText((firstName+" "+lastName).toUpperCase());
    admin_status_lb.setText(admin_sts);
    
}   
  
     /*public String getFirstName() {
        return this.firstName;   
    }*/
     

private ImageIcon createImageIcon(byte[] imageData) {
    try {
        // Convert byte array to BufferedImage
        ByteArrayInputStream bis = new ByteArrayInputStream(imageData);
        BufferedImage bImage = ImageIO.read(bis);

        // Resize the image as needed (optional)
        Image resizedImage = bImage.getScaledInstance(100, 100, Image.SCALE_SMOOTH);

        // Convert BufferedImage to ImageIcon
        return new ImageIcon(resizedImage);
    } catch (IOException e) {
        e.printStackTrace();
        return null;
    }
}
    private void home_panelBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_home_panelBMouseClicked
        // TODO add your handling code here:
        admin_home_panel.setVisible(true);
        admin_account_panel.setVisible(false);
        manage_books_panel.setVisible(false);
        manage_users_panel.setVisible(false);
        
        home_panelB.setBackground(panelcolor);
        account_panelB.setBackground(defcolor);
        manage_booksB.setBackground(defcolor);
        manage_usersB.setBackground(defcolor);
        
    }//GEN-LAST:event_home_panelBMouseClicked

    private void account_panelBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_account_panelBMouseClicked
        // TODO add your handling code here:
        admin_home_panel.setVisible(false);
        admin_account_panel.setVisible(true);
        manage_books_panel.setVisible(false);
        manage_users_panel.setVisible(false);
        
        home_panelB.setBackground(defcolor);
        account_panelB.setBackground(panelcolor);
        manage_booksB.setBackground(defcolor);
        manage_usersB.setBackground(defcolor);
        
        
    }//GEN-LAST:event_account_panelBMouseClicked

    private void manage_booksBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_manage_booksBMouseClicked
        // TODO add your handling code here:
        admin_home_panel.setVisible(false);
        admin_account_panel.setVisible(false);
        manage_books_panel.setVisible(true);
        manage_users_panel.setVisible(false);
        
        home_panelB.setBackground(defcolor);
        account_panelB.setBackground(defcolor);
        manage_booksB.setBackground(panelcolor);
        manage_usersB.setBackground(defcolor);
    }//GEN-LAST:event_manage_booksBMouseClicked

    private void manage_usersBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_manage_usersBMouseClicked
        // TODO add your handling code here:
        admin_home_panel.setVisible(false);
        admin_account_panel.setVisible(false);
        manage_books_panel.setVisible(false);
        manage_users_panel.setVisible(true);
        
        home_panelB.setBackground(defcolor);
        account_panelB.setBackground(defcolor);
        manage_booksB.setBackground(defcolor);
        manage_usersB.setBackground(panelcolor);
    }//GEN-LAST:event_manage_usersBMouseClicked

    private void add_userMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_add_userMouseClicked
        // TODO add your handling code here:
        
        addChoose choose_user = new addChoose();
        
        choose_user.setVisible(true);
        choose_user.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }//GEN-LAST:event_add_userMouseClicked

    private void admin_logoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_admin_logoutMouseClicked
        // TODO add your handling code here:
        logout_confirmation logout_c = new logout_confirmation(this);
        logout_c.setVisible(true);
        logout_c.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
    }//GEN-LAST:event_admin_logoutMouseClicked

    private void mbMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mbMouseClicked
        // TODO add your handling code here:
        manage_books_panel_c.setVisible(true);
        manage_request_panel.setVisible(false);
        accepted_borrowers_panel.setVisible(false);
        
        mb.setBackground(Color.WHITE);
        m_request.setBackground(defcolor);
        b_borrowers.setBackground(defcolor);
    }//GEN-LAST:event_mbMouseClicked

    private void m_requestMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_m_requestMouseClicked
        // TODO add your handling code here:
        manage_books_panel_c.setVisible(false);
        manage_request_panel.setVisible(true);
        accepted_borrowers_panel.setVisible(false);
        
        mb.setBackground(defcolor);
        m_request.setBackground(Color.WHITE);
        b_borrowers.setBackground(defcolor);
    }//GEN-LAST:event_m_requestMouseClicked

    private void b_borrowersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b_borrowersMouseClicked
        // TODO add your handling code here:
        manage_books_panel_c.setVisible(false);
        manage_request_panel.setVisible(false);
        accepted_borrowers_panel.setVisible(true);
        
        mb.setBackground(defcolor);
        m_request.setBackground(defcolor);
        b_borrowers.setBackground(Color.WHITE);
    }//GEN-LAST:event_b_borrowersMouseClicked

    private void add_book_bMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_add_book_bMouseClicked
        // TODO add your handling code here:
        
        add_books ab = new add_books();
        ab.setVisible(true);
        
    }//GEN-LAST:event_add_book_bMouseClicked

    private void refresh_tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_refresh_tableMouseClicked
        // TODO add your handling code here:
        book_category_filter.setSelectedIndex(-1);
        books_pub_filter.setSelectedIndex(-1);
        book_available_filter.setSelectedIndex(-1);
        searchTableBooks.setText("");
        refreshTable();
        
    }//GEN-LAST:event_refresh_tableMouseClicked

    private void total_student_btMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_total_student_btMouseClicked
        // TODO add your handling code here:
        total_admin_data.setVisible(false);
        active_admin_data.setVisible(false);
        inactive_admin_data.setVisible(false);
        total_student_data.setVisible(true);
        active_student_data.setVisible(false);
        inactive_student_data.setVisible(false);
        
        total_student_bt.setBackground(Color.WHITE);
        active_student_bt.setBackground(defcolor);
        inactive_student_bt.setBackground(defcolor);
        tota_admin_bt.setBackground(defcolor);
        active_admin_bt.setBackground(defcolor);
        inactive_admin_bt.setBackground(defcolor);
        
        total_student_p.setForeground(Color.BLACK);
        jLabel12.setForeground(Color.BLACK);
        student_active.setForeground(Color.WHITE);
        jLabel40.setForeground(Color.WHITE);
        student_inactive.setForeground(Color.WHITE);
        jLabel34.setForeground(Color.WHITE);
        total_admin_p.setForeground(Color.WHITE);
        jLabel13.setForeground(Color.WHITE);
        admin_active.setForeground(Color.WHITE);
        admin_inactive.setForeground(Color.WHITE);
        jLabel43.setForeground(Color.WHITE);
        jLabel44.setForeground(Color.WHITE);
        
    }//GEN-LAST:event_total_student_btMouseClicked

    private void active_student_btMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_active_student_btMouseClicked
        // TODO add your handling code here:
        total_admin_data.setVisible(false);
        active_admin_data.setVisible(false);
        inactive_admin_data.setVisible(false);
        total_student_data.setVisible(false);
        active_student_data.setVisible(true);
        inactive_student_data.setVisible(false);
        
        total_student_bt.setBackground(defcolor);
        active_student_bt.setBackground(Color.WHITE);
        inactive_student_bt.setBackground(defcolor);
        tota_admin_bt.setBackground(defcolor);
        active_admin_bt.setBackground(defcolor);
        inactive_admin_bt.setBackground(defcolor);
        
        total_student_p.setForeground(Color.WHITE);
        jLabel12.setForeground(Color.WHITE);
        student_active.setForeground(Color.BLACK);
        jLabel40.setForeground(Color.BLACK);
        student_inactive.setForeground(Color.WHITE);
        jLabel34.setForeground(Color.WHITE);
        total_admin_p.setForeground(Color.WHITE);
        jLabel13.setForeground(Color.WHITE);
        admin_active.setForeground(Color.WHITE);
        admin_inactive.setForeground(Color.WHITE);
        jLabel43.setForeground(Color.WHITE);
        jLabel44.setForeground(Color.WHITE);
    }//GEN-LAST:event_active_student_btMouseClicked

    private void inactive_student_btMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inactive_student_btMouseClicked
        // TODO add your handling code here:
        total_admin_data.setVisible(false);
        active_admin_data.setVisible(false);
        inactive_admin_data.setVisible(false);
        total_student_data.setVisible(false);
        active_student_data.setVisible(false);
        inactive_student_data.setVisible(true);
        
        total_student_bt.setBackground(defcolor);
        active_student_bt.setBackground(defcolor);
        inactive_student_bt.setBackground(Color.WHITE);
        tota_admin_bt.setBackground(defcolor);
        active_admin_bt.setBackground(defcolor);
        inactive_admin_bt.setBackground(defcolor);
        
        total_student_p.setForeground(Color.WHITE);
        jLabel12.setForeground(Color.WHITE);
        student_active.setForeground(Color.WHITE);
        jLabel40.setForeground(Color.WHITE);
        student_inactive.setForeground(Color.BLACK);
        jLabel34.setForeground(Color.BLACK);
        total_admin_p.setForeground(Color.WHITE);
        jLabel13.setForeground(Color.WHITE);
        admin_active.setForeground(Color.WHITE);
        admin_inactive.setForeground(Color.WHITE);
        jLabel43.setForeground(Color.WHITE);
        jLabel44.setForeground(Color.WHITE);
    }//GEN-LAST:event_inactive_student_btMouseClicked

    private void tota_admin_btMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tota_admin_btMouseClicked
        // TODO add your handling code here:
        total_admin_data.setVisible(true);
        active_admin_data.setVisible(false);
        inactive_admin_data.setVisible(false);
        total_student_data.setVisible(false);
        active_student_data.setVisible(false);
        inactive_student_data.setVisible(false);
        
        total_student_bt.setBackground(defcolor);
        active_student_bt.setBackground(defcolor);
        inactive_student_bt.setBackground(defcolor);
        tota_admin_bt.setBackground(Color.WHITE);
        active_admin_bt.setBackground(defcolor);
        inactive_admin_bt.setBackground(defcolor);
        
        total_student_p.setForeground(Color.WHITE);
        jLabel12.setForeground(Color.WHITE);
        student_active.setForeground(Color.WHITE);
        jLabel40.setForeground(Color.WHITE);
        student_inactive.setForeground(Color.WHITE);
        jLabel34.setForeground(Color.WHITE);
        total_admin_p.setForeground(Color.BLACK);
        jLabel13.setForeground(Color.BLACK);
        admin_active.setForeground(Color.WHITE);
        admin_inactive.setForeground(Color.WHITE);
        jLabel43.setForeground(Color.WHITE);
        jLabel44.setForeground(Color.WHITE);
    }//GEN-LAST:event_tota_admin_btMouseClicked

    private void active_admin_btMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_active_admin_btMouseClicked
        // TODO add your handling code here:
        total_admin_data.setVisible(false);
        active_admin_data.setVisible(true);
        inactive_admin_data.setVisible(false);
        total_student_data.setVisible(false);
        active_student_data.setVisible(false);
        inactive_student_data.setVisible(false);
        
        total_student_bt.setBackground(defcolor);
        active_student_bt.setBackground(defcolor);
        inactive_student_bt.setBackground(defcolor);
        tota_admin_bt.setBackground(defcolor);
        active_admin_bt.setBackground(Color.WHITE);
        inactive_admin_bt.setBackground(defcolor);
        
        total_student_p.setForeground(Color.WHITE);
        jLabel12.setForeground(Color.WHITE);
        student_active.setForeground(Color.WHITE);
        jLabel40.setForeground(Color.WHITE);
        student_inactive.setForeground(Color.WHITE);
        jLabel34.setForeground(Color.WHITE);
        total_admin_p.setForeground(Color.WHITE);
        jLabel13.setForeground(Color.WHITE);
        admin_active.setForeground(Color.BLACK);
        jLabel43.setForeground(Color.BLACK);
        admin_inactive.setForeground(Color.WHITE);
        
        jLabel44.setForeground(Color.WHITE);
    }//GEN-LAST:event_active_admin_btMouseClicked

    private void inactive_admin_btMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inactive_admin_btMouseClicked
        // TODO add your handling code here:
        total_admin_data.setVisible(false);
        active_admin_data.setVisible(false);
        inactive_admin_data.setVisible(true);
        total_student_data.setVisible(false);
        active_student_data.setVisible(false);
        inactive_student_data.setVisible(false);
        
        total_student_bt.setBackground(defcolor);
        active_student_bt.setBackground(defcolor);
        inactive_student_bt.setBackground(defcolor);
        tota_admin_bt.setBackground(defcolor);
        active_admin_bt.setBackground(defcolor);
        inactive_admin_bt.setBackground(Color.WHITE);
        
        total_student_p.setForeground(Color.WHITE);
        jLabel12.setForeground(Color.WHITE);
        student_active.setForeground(Color.WHITE);
        jLabel40.setForeground(Color.WHITE);
        student_inactive.setForeground(Color.WHITE);
        jLabel34.setForeground(Color.WHITE);
        total_admin_p.setForeground(Color.WHITE);
        jLabel13.setForeground(Color.WHITE);
        admin_active.setForeground(Color.WHITE);
        jLabel43.setForeground(Color.WHITE);
        admin_inactive.setForeground(Color.BLACK);
        
        jLabel44.setForeground(Color.BLACK);
    }//GEN-LAST:event_inactive_admin_btMouseClicked

    private void searchBtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBtActionPerformed
        // TODO add your handling code here:
        book_category_filter.setSelectedIndex(-1);
        books_pub_filter.setSelectedIndex(-1);
        book_available_filter.setSelectedIndex(-1);
       
        
        filterTableField();
    }//GEN-LAST:event_searchBtActionPerformed

    private void update_user_btMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_update_user_btMouseClicked
        // TODO add your handling code here:
        choose_user_update chsUp = new choose_user_update();
        chsUp.setVisible(true);
        
    }//GEN-LAST:event_update_user_btMouseClicked

    private void actDeact_userMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_actDeact_userMouseClicked
        // TODO add your handling code here:
        choose_user_actdeact choose_usr = new choose_user_actdeact();
        choose_usr.setVisible(true);
    }//GEN-LAST:event_actDeact_userMouseClicked

    private void archived_book_btMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_archived_book_btMouseClicked
        // TODO add your handling code here:
        archived_books archived_b = new archived_books();
        archived_b.setVisible(true);
    }//GEN-LAST:event_archived_book_btMouseClicked

    private void update_announce_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_announce_btActionPerformed
        // TODO add your handling code here:
        getannouncement = lib_announcement.getText();
        String url = "jdbc:h2:~/test";
        String user = "sa";
        String database_password = "glen";

        try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
            String sql = "UPDATE LIBRARY_ANNOUNCEMENT SET announcement =?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                // Set the parameters for the update
                preparedStatement.setString(1, getannouncement);

                // Execute the update
                preparedStatement.executeUpdate();
                displayAnnouncement();

                
                JOptionPane.showMessageDialog(this, "Announcement Updated", "", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_update_announce_btActionPerformed
    public static void refreshTable() {
    SwingUtilities.invokeLater(() -> {
        DefaultTableModel model = (DefaultTableModel) lms_books_table.getModel();
        model.setRowCount(0); // Clear existing rows from the table
        displayBooksInTable(); // Fetch and display fresh data
    });
}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        FlatLightLaf.setup();
        
        /*try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        }
        catch (Exception e){
          e.printStackTrace();
        }
        */       

        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        /*try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(admin_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(admin_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(admin_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(admin_dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        */
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new admin_dashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel accepted_borrowers_panel;
    private javax.swing.JPanel account_panelB;
    private javax.swing.JPanel actDeact_user;
    private javax.swing.JPanel active_admin_bt;
    private javax.swing.JPanel active_admin_data;
    private static javax.swing.JTable active_admin_tb2;
    private javax.swing.JPanel active_student_bt;
    private javax.swing.JPanel active_student_data;
    private static javax.swing.JTable active_student_tb2;
    private javax.swing.JPanel add_book_b;
    private javax.swing.JPanel add_user;
    private javax.swing.JLabel adminImage;
    private javax.swing.JLabel adminName;
    private javax.swing.JPanel admin_account_panel;
    private static javax.swing.JLabel admin_active;
    private javax.swing.JLabel admin_email_i;
    private javax.swing.JPanel admin_home_panel;
    private javax.swing.JLabel admin_id_number;
    private static javax.swing.JLabel admin_inactive;
    private javax.swing.JLabel admin_issued_i;
    private javax.swing.JLabel admin_logout;
    public javax.swing.JLabel admin_name_i;
    private javax.swing.JLabel admin_sex_i;
    private javax.swing.JLabel admin_status_lb;
    private javax.swing.JLabel admin_tel_i;
    private javax.swing.JPanel archived_book_bt;
    private javax.swing.JPanel b_borrowers;
    private static javax.swing.JComboBox<String> book_available_filter;
    private static javax.swing.JTable book_borrowers_data;
    private static javax.swing.JComboBox<String> book_category_filter;
    private static javax.swing.JComboBox<String> books_pub_filter;
    private javax.swing.JLabel clock_feature;
    private javax.swing.JPanel conatine_of_tables;
    private javax.swing.JPanel conatiner_books;
    private javax.swing.JLabel home_date;
    private javax.swing.JPanel home_panelB;
    private javax.swing.JPanel inactive_admin_bt;
    private javax.swing.JPanel inactive_admin_data;
    private static javax.swing.JTable inactive_admin_tb3;
    private javax.swing.JPanel inactive_student_bt;
    private javax.swing.JPanel inactive_student_data;
    private static javax.swing.JTable inactive_student_tb3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private static javax.swing.JTextArea lib_announcement;
    private static javax.swing.JTable lms_books_table;
    private javax.swing.JPanel m_request;
    private javax.swing.JPanel manage_booksB;
    private javax.swing.JPanel manage_books_panel;
    private javax.swing.JPanel manage_books_panel_c;
    private static javax.swing.JTable manage_request_data;
    private javax.swing.JPanel manage_request_panel;
    private javax.swing.JPanel manage_usersB;
    private javax.swing.JPanel manage_users_panel;
    private javax.swing.JPanel mb;
    private javax.swing.JPanel panel_containers;
    private javax.swing.JPanel refresh_table;
    private javax.swing.JButton searchBt;
    private static javax.swing.JTextField searchTableBooks;
    private javax.swing.JPanel side_bar_navigation;
    private static javax.swing.JLabel student_active;
    private static javax.swing.JLabel student_inactive;
    private javax.swing.JPanel tota_admin_bt;
    private javax.swing.JPanel total_admin_data;
    private static javax.swing.JLabel total_admin_p;
    private static javax.swing.JTable total_admin_tb1;
    private static javax.swing.JLabel total_books;
    private javax.swing.JPanel total_student_bt;
    private javax.swing.JPanel total_student_data;
    private static javax.swing.JLabel total_student_p;
    private static javax.swing.JTable total_student_tb1;
    private javax.swing.JButton update_announce_bt;
    private javax.swing.JPanel update_user_bt;
    // End of variables declaration//GEN-END:variables
class RoundedPanel extends JPanel
    {
        //private static Color panelcolor = new Color(109, 139, 116);
        private Color backgroundColor;
        private int cornerRadius = 15;
        public RoundedPanel(LayoutManager layout, int radius) {
            super(layout);
            cornerRadius = radius;
            setOpaque(false);
        }
        public RoundedPanel(LayoutManager layout, int radius, Color bgColor) {
            super(layout);
            cornerRadius = radius;
            backgroundColor = bgColor;
            setOpaque(false);
        }
        public RoundedPanel(int radius) {
            super();
            cornerRadius = radius;
            setOpaque(false);
            
        }
        public RoundedPanel(int radius, Color bgColor) {
            super();
            cornerRadius = radius;
            backgroundColor = bgColor;
            setOpaque(false);
        }
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Dimension arcs = new Dimension(cornerRadius, cornerRadius);
            int width = getWidth();
            int height = getHeight();
            Graphics2D graphics = (Graphics2D) g;
            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            //Draws the rounded panel with borders.
            if (backgroundColor != null) {
                graphics.setColor(backgroundColor);
            } else {
                graphics.setColor(getBackground());
            }
            graphics.fillRoundRect(0, 0, width-1, height-1, arcs.width, arcs.height); //paint background
            graphics.setColor(getForeground());
//            graphics.drawRoundRect(0, 0, width-1, height-1, arcs.width, arcs.height); //paint border
//             
        }
    }
    public static void displayBooksInTable() {
        DefaultTableModel model = (DefaultTableModel) lms_books_table.getModel();
        model.setRowCount(0); // Clear existing rows from the table
        
        // Set up cell renderer for center alignment
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
    
    // Apply the renderer to all columns in the table
        int columnCount = lms_books_table.getColumnCount();
        for (int i = 0; i < columnCount; i++) {
        lms_books_table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
         // Set up header renderer for center alignment
        JTableHeader header = lms_books_table.getTableHeader();
        DefaultTableCellRenderer headerRenderer = (DefaultTableCellRenderer) header.getDefaultRenderer();
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        
        
        //lms_books_table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        lms_books_table.getTableHeader().setForeground(Color.BLACK);
        lms_books_table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lms_books_table.setRowHeight(25);
        lms_books_table.setSelectionBackground(new Color(109,139,116));
        lms_books_table.setSelectionForeground(Color.WHITE);
        
        String url = "jdbc:h2:~/test";
        String user = "sa";
        String database_password = "glen";

        try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
            String sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String accNo = resultSet.getString("acc_no");
                        String bookTitle = resultSet.getString("book_title");
                        String bookAuthor = resultSet.getString("book_author");
                        String bookCategory = resultSet.getString("book_category");
                        int bookAvailable = resultSet.getInt("book_available");
                        String bookBorrow = resultSet.getString("book_borrow");
                        String publicationYear = resultSet.getString("publication_year");
                        String bookDescription = resultSet.getString("book_description");
                        byte[] imageData = resultSet.getBytes("book_image");
                        ImageIcon bookImageIcon = new ImageIcon(imageData);

                        model.addRow(new Object[]{accNo, bookTitle.toUpperCase(), bookAuthor.toUpperCase(), bookCategory.toUpperCase(), bookAvailable, bookBorrow.toUpperCase(), publicationYear, bookDescription, bookImageIcon});
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        int columnIndexToHide8 = 8;
        int columnIndexToHide7 = 7;
       if (columnIndexToHide8 < lms_books_table.getColumnCount()) {
            TableColumn column = lms_books_table.getColumnModel().getColumn(columnIndexToHide8);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide8);
        }
       if (columnIndexToHide7 < lms_books_table.getColumnCount()) {
            TableColumn column = lms_books_table.getColumnModel().getColumn(columnIndexToHide7);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide7);
        }
        
        
    
    
}
    public static void DisplayAdminData() {
        DefaultTableModel model = (DefaultTableModel) total_admin_tb1.getModel();
        model.setRowCount(0); // Clear existing rows from the table
        
        // Set up cell renderer for center alignment
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
    
    // Apply the renderer to all columns in the table
        int columnCount = total_admin_tb1.getColumnCount();
        for (int i = 0; i < columnCount; i++) {
        total_admin_tb1.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
         // Set up header renderer for center alignment
        JTableHeader header = total_admin_tb1.getTableHeader();
        DefaultTableCellRenderer headerRenderer = (DefaultTableCellRenderer) header.getDefaultRenderer();
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        
        
        //lms_books_table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        total_admin_tb1.getTableHeader().setForeground(Color.BLACK);
        total_admin_tb1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        total_admin_tb1.setRowHeight(25);
        total_admin_tb1.setSelectionBackground(new Color(109,139,116));
        total_admin_tb1.setSelectionForeground(Color.WHITE);
        
        
        String url = "jdbc:h2:~/test";
        String user = "sa";
        String database_password = "glen";

        try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
            String sql = "SELECT * FROM ADMIN";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String admin_id = resultSet.getString("adminID");
                        String admin_fname = resultSet.getString("first_name");
                        String admin_lname = resultSet.getString("last_name");
                        String admin_sx = resultSet.getString("sex");
                        
                        String admin_eml = resultSet.getString("email");
                        
                        String admin_tel_n = resultSet.getString("telephone_no");
                        Date isd_dt = resultSet.getDate("issued_date");
                        int Status_ad = resultSet.getInt("status");
                        String statusText = (Status_ad == 1) ? "Active" : "Inactive";

                        model.addRow(new Object[]{admin_id, admin_fname.toUpperCase(), admin_lname.toUpperCase(),admin_sx.toUpperCase(), admin_eml, admin_tel_n, isd_dt, statusText.toUpperCase()});
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        
    
}
    public static void DisplayActiveAdmin() {
        DefaultTableModel model = (DefaultTableModel) active_admin_tb2.getModel();
        model.setRowCount(0); // Clear existing rows from the table
        
        // Set up cell renderer for center alignment
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
    
    // Apply the renderer to all columns in the table
        int columnCount = active_admin_tb2.getColumnCount();
        for (int i = 0; i < columnCount; i++) {
        active_admin_tb2.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
         // Set up header renderer for center alignment
        JTableHeader header = active_admin_tb2.getTableHeader();
        DefaultTableCellRenderer headerRenderer = (DefaultTableCellRenderer) header.getDefaultRenderer();
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        
        
        //lms_books_table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        active_admin_tb2.getTableHeader().setForeground(Color.BLACK);
        active_admin_tb2.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        active_admin_tb2.setRowHeight(25);
        active_admin_tb2.setSelectionBackground(new Color(109,139,116));
        active_admin_tb2.setSelectionForeground(Color.WHITE);
        
        
        String url = "jdbc:h2:~/test";
        String user = "sa";
        String database_password = "glen";

        try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
            String sql = "SELECT * FROM ADMIN WHERE status = 1";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String admin_id = resultSet.getString("adminID");
                        String admin_fname = resultSet.getString("first_name");
                        String admin_lname = resultSet.getString("last_name");
                        String admin_sx = resultSet.getString("sex");
                        
                        String admin_eml = resultSet.getString("email");
                        
                        String admin_tel_n = resultSet.getString("telephone_no");
                        Date isd_dt = resultSet.getDate("issued_date");
                        int Status_ad = resultSet.getInt("status");
                        String statusText = (Status_ad == 1) ? "Active" : "Inactive";

                        model.addRow(new Object[]{admin_id, admin_fname.toUpperCase(), admin_lname.toUpperCase(),admin_sx.toUpperCase(), admin_eml, admin_tel_n, isd_dt, statusText.toUpperCase()});
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
}
    public static void DisplayInactiveAdmin() {
        DefaultTableModel model = (DefaultTableModel) inactive_admin_tb3.getModel();
        model.setRowCount(0); // Clear existing rows from the table
        
        // Set up cell renderer for center alignment
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
    
    // Apply the renderer to all columns in the table
        int columnCount = inactive_admin_tb3.getColumnCount();
        for (int i = 0; i < columnCount; i++) {
        inactive_admin_tb3.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
         // Set up header renderer for center alignment
        JTableHeader header = inactive_admin_tb3.getTableHeader();
        DefaultTableCellRenderer headerRenderer = (DefaultTableCellRenderer) header.getDefaultRenderer();
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        
        
        //lms_books_table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        inactive_admin_tb3.getTableHeader().setForeground(Color.BLACK);
        inactive_admin_tb3.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        inactive_admin_tb3.setRowHeight(25);
        inactive_admin_tb3.setSelectionBackground(new Color(109,139,116));
        inactive_admin_tb3.setSelectionForeground(Color.WHITE);
        
        
        String url = "jdbc:h2:~/test";
        String user = "sa";
        String database_password = "glen";

        try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
            String sql = "SELECT * FROM ADMIN WHERE status = 0";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String admin_id = resultSet.getString("adminID");
                        String admin_fname = resultSet.getString("first_name");
                        String admin_lname = resultSet.getString("last_name");
                        String admin_sx = resultSet.getString("sex");
                        
                        String admin_eml = resultSet.getString("email");
                        
                        String admin_tel_n = resultSet.getString("telephone_no");
                        Date isd_dt = resultSet.getDate("issued_date");
                        int Status_ad = resultSet.getInt("status");
                        String statusText = (Status_ad == 1) ? "Active" : "Inactive";

                        model.addRow(new Object[]{admin_id, admin_fname.toUpperCase(), admin_lname.toUpperCase(),admin_sx.toUpperCase(), admin_eml, admin_tel_n, isd_dt, statusText.toUpperCase()});
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
}
    public static void DisplayTotalStudent() {
        DefaultTableModel model = (DefaultTableModel) total_student_tb1.getModel();
        model.setRowCount(0); // Clear existing rows from the table
        
        // Set up cell renderer for center alignment
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
    
    // Apply the renderer to all columns in the table
        int columnCount = total_student_tb1.getColumnCount();
        for (int i = 0; i < columnCount; i++) {
        total_student_tb1.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
         // Set up header renderer for center alignment
        JTableHeader header = total_student_tb1.getTableHeader();
        DefaultTableCellRenderer headerRenderer = (DefaultTableCellRenderer) header.getDefaultRenderer();
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        
        
        //lms_books_table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        total_student_tb1.getTableHeader().setForeground(Color.BLACK);
        total_student_tb1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        total_student_tb1.setRowHeight(25);
        total_student_tb1.setSelectionBackground(new Color(109,139,116));
        total_student_tb1.setSelectionForeground(Color.WHITE);
        
        
        String url = "jdbc:h2:~/test";
        String user = "sa";
        String database_password = "glen";

        try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
            String sql = "SELECT * FROM LMSTUDENTS";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String student_id = resultSet.getString("studentID");
                        String student_fname = resultSet.getString("first_name");
                        String student_lname = resultSet.getString("last_name");
                        String student_sx = resultSet.getString("sex");
                        String student_age = resultSet.getString("student_age");
                        String student_add = resultSet.getString("home_address");
                        
                        String student_eml = resultSet.getString("email");
                        
                        String student_tel_n = resultSet.getString("telephone_no");
                        String student_Course = resultSet.getString("course");
                        String student_sec = resultSet.getString("section");
                        String student_Year = resultSet.getString("student_year");
                        Date isd_dt = resultSet.getDate("issued_date");
                        int Status_ad = resultSet.getInt("status");
                        String statusText = (Status_ad == 1) ? "Active" : "Inactive";

                        model.addRow(new Object[]{student_id, student_fname.toUpperCase(), student_lname.toUpperCase(),student_age, student_sx.toUpperCase(), student_eml, student_add.toUpperCase(), student_tel_n, student_Year, student_Course, student_sec.toUpperCase(), isd_dt, statusText.toUpperCase(),});
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
}
    public static void DisplayActiveStudent() {
        DefaultTableModel model = (DefaultTableModel) active_student_tb2.getModel();
        model.setRowCount(0); // Clear existing rows from the table
        
        // Set up cell renderer for center alignment
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
    
    // Apply the renderer to all columns in the table
        int columnCount = active_student_tb2.getColumnCount();
        for (int i = 0; i < columnCount; i++) {
        active_student_tb2.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
         // Set up header renderer for center alignment
        JTableHeader header = active_student_tb2.getTableHeader();
        DefaultTableCellRenderer headerRenderer = (DefaultTableCellRenderer) header.getDefaultRenderer();
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        
        
        //lms_books_table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        active_student_tb2.getTableHeader().setForeground(Color.BLACK);
        active_student_tb2.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        active_student_tb2.setRowHeight(25);
        active_student_tb2.setSelectionBackground(new Color(109,139,116));
        active_student_tb2.setSelectionForeground(Color.WHITE);
        
        
        String url = "jdbc:h2:~/test";
        String user = "sa";
        String database_password = "glen";

        try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
            String sql = "SELECT * FROM LMSTUDENTS WHERE status = 1";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String student_id = resultSet.getString("studentID");
                        String student_fname = resultSet.getString("first_name");
                        String student_lname = resultSet.getString("last_name");
                        String student_sx = resultSet.getString("sex");
                        String student_age = resultSet.getString("student_age");
                        String student_add = resultSet.getString("home_address");
                        
                        String student_eml = resultSet.getString("email");
                        
                        String student_tel_n = resultSet.getString("telephone_no");
                        String student_Course = resultSet.getString("course");
                        String student_sec = resultSet.getString("section");
                        String student_Year = resultSet.getString("student_year");
                        Date isd_dt = resultSet.getDate("issued_date");
                        int Status_ad = resultSet.getInt("status");
                        String statusText = (Status_ad == 1) ? "Active" : "Inactive";

                        model.addRow(new Object[]{student_id, student_fname.toUpperCase(), student_lname.toUpperCase(),student_age, student_sx.toUpperCase(), student_eml, student_add.toUpperCase(), student_tel_n, student_Year, student_Course, student_sec.toUpperCase(), isd_dt, statusText.toUpperCase(),});
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
}
    public static void DisplayInactiveStudent() {
        DefaultTableModel model = (DefaultTableModel) inactive_student_tb3.getModel();
        model.setRowCount(0); // Clear existing rows from the table
        
        // Set up cell renderer for center alignment
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
    
    // Apply the renderer to all columns in the table
        int columnCount = inactive_student_tb3.getColumnCount();
        for (int i = 0; i < columnCount; i++) {
        inactive_student_tb3.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
         // Set up header renderer for center alignment
        JTableHeader header = inactive_student_tb3.getTableHeader();
        DefaultTableCellRenderer headerRenderer = (DefaultTableCellRenderer) header.getDefaultRenderer();
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        
        
        //lms_books_table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        inactive_student_tb3.getTableHeader().setForeground(Color.BLACK);
        inactive_student_tb3.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        inactive_student_tb3.setRowHeight(25);
        inactive_student_tb3.setSelectionBackground(new Color(109,139,116));
        inactive_student_tb3.setSelectionForeground(Color.WHITE);
        
        
        String url = "jdbc:h2:~/test";
        String user = "sa";
        String database_password = "glen";

        try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
            String sql = "SELECT * FROM LMSTUDENTS WHERE status = 0";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String student_id = resultSet.getString("studentID");
                        String student_fname = resultSet.getString("first_name");
                        String student_lname = resultSet.getString("last_name");
                        String student_sx = resultSet.getString("sex");
                        String student_age = resultSet.getString("student_age");
                        String student_add = resultSet.getString("home_address");
                        
                        String student_eml = resultSet.getString("email");
                        
                        String student_tel_n = resultSet.getString("telephone_no");
                        String student_Course = resultSet.getString("course");
                        String student_sec = resultSet.getString("section");
                        String student_Year = resultSet.getString("student_year");
                        Date isd_dt = resultSet.getDate("issued_date");
                        int Status_ad = resultSet.getInt("status");
                        String statusText = (Status_ad == 1) ? "Active" : "Inactive";

                        model.addRow(new Object[]{student_id, student_fname.toUpperCase(), student_lname.toUpperCase(),student_age, student_sx.toUpperCase(), student_eml, student_add.toUpperCase(), student_tel_n, student_Year, student_Course, student_sec.toUpperCase(), isd_dt, statusText.toUpperCase(),});
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
}
    public static void displayRequestBookData() {
    DefaultTableModel model = (DefaultTableModel) manage_request_data.getModel();
    model.setRowCount(0); // Clear existing rows from the table

    // Set up cell renderer for center alignment
    DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
    centerRenderer.setHorizontalAlignment(JLabel.CENTER);

    // Apply the renderer to all columns in the table
    int columnCount = manage_request_data.getColumnCount();
    for (int i = 0; i < columnCount; i++) {
        manage_request_data.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
    }

    // Set up header renderer for center alignment
    JTableHeader header = manage_request_data.getTableHeader();
    DefaultTableCellRenderer headerRenderer = (DefaultTableCellRenderer) header.getDefaultRenderer();
    headerRenderer.setHorizontalAlignment(JLabel.CENTER);

    //lms_books_table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
    manage_request_data.getTableHeader().setForeground(Color.BLACK);
    manage_request_data.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    manage_request_data.setRowHeight(25);
    manage_request_data.setSelectionBackground(new Color(109, 139, 116));
    manage_request_data.setSelectionForeground(Color.WHITE);
     
    
    
    String url = "jdbc:h2:~/test";
    String user = "sa";
    String database_password = "glen";
    //String studentID = getStudNo;
    try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
        String sql = "SELECT LS.first_name, LS.last_name, LS.email, LS.student_image, RB.studentID, RB.acc_no, LB.book_title, LB.book_author, LB.book_category, LB.publication_year, LB.book_description, LB.book_image, RB.date_added " +
                "FROM REQUESTED_BOOKS RB " +
                "JOIN LIBRARY_BOOKS LB ON RB.acc_no = LB.acc_no " +
                "JOIN LMSTUDENTS LS ON RB.studentID = LS.studentID ";
                
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            // Set the parameter for studentID
            //preparedStatement.setString(1, studentID);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    String studID = resultSet.getString("studentID");
                    String firstN = resultSet.getString("first_name");
                    String lastN = resultSet.getString("last_name");
                    String studEmail = resultSet.getString("email");
                    String accN = resultSet.getString("acc_no");
                    String bookTitle = resultSet.getString("book_title");
                    String bookAuthor = resultSet.getString("book_author");
                    String bookCategory = resultSet.getString("book_category");
                    String publicationYear = resultSet.getString("publication_year");
                    String Bdescription = resultSet.getString("book_description");
                    byte[] imageData = resultSet.getBytes("book_image");
                    ImageIcon bookImageIcon = new ImageIcon(imageData);
                    byte[] studentImageData = resultSet.getBytes("student_image");
                    ImageIcon studImageIcon = new ImageIcon(studentImageData);
                    Date dateAdded = resultSet.getDate("date_added");
                    model.addRow(new Object[]{studID, firstN.toUpperCase(), lastN.toUpperCase(), studEmail, accN, bookTitle, bookAuthor, bookCategory, publicationYear, Bdescription, bookImageIcon, studImageIcon, dateAdded});
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
       int columnIndexToHide = 1;
       int columnIndexToHide3 = 2;
       int columnIndexToHide4 = 3;
       int columnIndexToHide5 = 4;
       int columnIndexToHide6 = 6;
       int columnIndexToHide7 = 7;
       int columnIndexToHide8 = 8;
       int columnIndexToHide9 = 9;
       int columnIndexToHide10 = 10;
       int columnIndexToHide11 = 11;
       if (columnIndexToHide < manage_request_data.getColumnCount()) {
            TableColumn column = manage_request_data.getColumnModel().getColumn(columnIndexToHide);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide);
        }
       if (columnIndexToHide3 < manage_request_data.getColumnCount()) {
            TableColumn column = manage_request_data.getColumnModel().getColumn(columnIndexToHide3);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide);
        }
       if (columnIndexToHide4 < manage_request_data.getColumnCount()) {
            TableColumn column = manage_request_data.getColumnModel().getColumn(columnIndexToHide4);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide);
        }
       
       if (columnIndexToHide6 < manage_request_data.getColumnCount()) {
            TableColumn column = manage_request_data.getColumnModel().getColumn(columnIndexToHide6);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide);
        }
       if (columnIndexToHide7 < manage_request_data.getColumnCount()) {
            TableColumn column = manage_request_data.getColumnModel().getColumn(columnIndexToHide7);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide);
        }
       if (columnIndexToHide8 < manage_request_data.getColumnCount()) {
            TableColumn column = manage_request_data.getColumnModel().getColumn(columnIndexToHide8);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide);
        }
      if (columnIndexToHide9 < manage_request_data.getColumnCount()) {
            TableColumn column = manage_request_data.getColumnModel().getColumn(columnIndexToHide9);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide);
        }
      if (columnIndexToHide10 < manage_request_data.getColumnCount()) {
            TableColumn column = manage_request_data.getColumnModel().getColumn(columnIndexToHide10);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide);
        }
      if (columnIndexToHide11 < manage_request_data.getColumnCount()) {
            TableColumn column = manage_request_data.getColumnModel().getColumn(columnIndexToHide11);
            column.setMinWidth(0);
            column.setMaxWidth(0);
            column.setPreferredWidth(0);
        } else {
            System.out.println("Invalid column index to hide: " + columnIndexToHide);
        }
    
        
}
    public static void displayBookBorrowers() {
    DefaultTableModel model = (DefaultTableModel) book_borrowers_data.getModel();
    model.setRowCount(0); // Clear existing rows from the table

    // Set up cell renderer for center alignment
    DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
    centerRenderer.setHorizontalAlignment(JLabel.CENTER);

    // Apply the renderer to all columns in the table
    int columnCount = book_borrowers_data.getColumnCount();
    for (int i = 0; i < columnCount; i++) {
        book_borrowers_data.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
    }

    // Set up header renderer for center alignment
    JTableHeader header = book_borrowers_data.getTableHeader();
    DefaultTableCellRenderer headerRenderer = (DefaultTableCellRenderer) header.getDefaultRenderer();
    headerRenderer.setHorizontalAlignment(JLabel.CENTER);

    //lms_books_table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
    book_borrowers_data.getTableHeader().setForeground(Color.BLACK);
    book_borrowers_data.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    book_borrowers_data.setRowHeight(25);
    book_borrowers_data.setSelectionBackground(new Color(109, 139, 116));
    book_borrowers_data.setSelectionForeground(Color.WHITE);
     
    
    
    String url = "jdbc:h2:~/test";
        String user = "sa";
        String database_password = "glen";

        try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
            String sql = "SELECT BR.studentID, BR.acc_no, LB.book_title, LB.book_author, LB.book_category, LB.publication_year, BR.date_added, BR.return_duedate, BR.book_penalty " +
                    "FROM BOOK_BORROWERS BR " +
                    "JOIN LIBRARY_BOOKS LB ON BR.acc_no = LB.acc_no ";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String StudID = resultSet.getString("studentID");
                        String accNo = resultSet.getString("acc_no");
                        String bookTitle = resultSet.getString("book_title");
                        String bookAuthor = resultSet.getString("book_author");
                        String bookCategory = resultSet.getString("book_category");
                        String publicationYear = resultSet.getString("publication_year");
                        Date dateAdded = resultSet.getDate("date_added");
                        Date returnDate = resultSet.getDate("return_duedate");
                        int bookPenalty = resultSet.getInt("book_penalty");

                        // Calculate penalty based on the difference between current date and return due date
                        int penaltyPerDay = 10;
                        Calendar calendarReturnDate = Calendar.getInstance();
                        calendarReturnDate.setTime(returnDate);
                        LocalDate localReturnDate = LocalDate.of(
                    calendarReturnDate.get(Calendar.YEAR),
                        calendarReturnDate.get(Calendar.MONTH) + 1,
               calendarReturnDate.get(Calendar.DAY_OF_MONTH)
                        );

                        long overdueDays = Math.max(0, ChronoUnit.DAYS.between(localReturnDate, LocalDate.now()));

                        int calculatedPenalty = (int) (overdueDays * penaltyPerDay);

                        // Update the book_penalty column with the calculated penalty
                        String updateSql = "UPDATE BOOK_BORROWERS SET book_penalty = ? WHERE acc_no = ?";
                        try (PreparedStatement updateStatement = connection.prepareStatement(updateSql)) {
                            updateStatement.setInt(1, calculatedPenalty);
                            updateStatement.setString(2, accNo);
                            updateStatement.executeUpdate();
                        }

                        model.addRow(new Object[]{StudID, accNo, bookTitle.toUpperCase(), bookAuthor.toUpperCase(), bookCategory.toUpperCase(), publicationYear, dateAdded, returnDate, bookPenalty});
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private static void filterTableField() {
        DefaultTableModel model = (DefaultTableModel) lms_books_table.getModel();
        String searchText = searchTableBooks.getText().trim().toUpperCase();
        
       

        // Remove all rows from the table
        model.setRowCount(0);

        String url = "jdbc:h2:~/test";
        String user = "sa";
        String database_password = "glen";
        

    try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
    String sql;
    if (searchText.isEmpty()) {
        // Display all books if the search text is empty
        sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1";
    } else {
        // Display filtered books based on search text
        sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1 AND (UPPER(acc_no) LIKE ? OR UPPER(book_title) LIKE ?)";
    }

    try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
        if (!searchText.isEmpty()) {
            preparedStatement.setString(1, "%" + searchText + "%");
            preparedStatement.setString(2, "%" + searchText + "%");
        }

        try (ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                String accNo = resultSet.getString("acc_no");
                String bookTitle = resultSet.getString("book_title");
                String bookAuthor = resultSet.getString("book_author");
                String bookCategory = resultSet.getString("book_category");
                int bookAvailable = resultSet.getInt("book_available");
                String bookBorrow = resultSet.getString("book_borrow");
                String publicationYear = resultSet.getString("publication_year");
                String bookDescription = resultSet.getString("book_description");
                byte[] imageData = resultSet.getBytes("book_image");
                ImageIcon bookImageIcon = new ImageIcon(imageData);
                model.addRow(new Object[]{accNo, bookTitle.toUpperCase(), bookAuthor.toUpperCase(), bookCategory.toUpperCase(), bookAvailable, bookBorrow.toUpperCase(), publicationYear, bookDescription, bookImageIcon});
            }
        }
    }
} catch (SQLException e) {
    e.printStackTrace();
}

      
    }
    private static void displayBookCategory(String selectedCategory) {
    DefaultTableModel model = (DefaultTableModel) lms_books_table.getModel();
    model.setRowCount(0); 
    
    String url = "jdbc:h2:~/test";
    String user = "sa";
    String database_password = "glen";

    try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
        String sql;
        
            
        sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1 AND publication_year = ?";
        

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            
                preparedStatement.setString(1, selectedCategory);
            

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    
                    String accNo = resultSet.getString("acc_no");
                    String bookTitle = resultSet.getString("book_title");
                    String bookAuthor = resultSet.getString("book_author");
                    String bookCategory = resultSet.getString("book_category");
                    int bookAvailable = resultSet.getInt("book_available");
                    String bookBorrow = resultSet.getString("book_borrow");
                    String publicationYear = resultSet.getString("publication_year");
                    String bookDescription = resultSet.getString("book_description");
                    byte[] imageData = resultSet.getBytes("book_image");
                    ImageIcon bookImageIcon = new ImageIcon(imageData);
                    
                    model.addRow(new Object[]{accNo, bookTitle.toUpperCase(), bookAuthor.toUpperCase(), bookCategory.toUpperCase(), bookAvailable, bookBorrow.toUpperCase(), publicationYear, bookDescription, bookImageIcon});
                    
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    
    private static void displayBooksByCategory(String selectedCategory) {
    DefaultTableModel model = (DefaultTableModel) lms_books_table.getModel();
    model.setRowCount(0); // Clear existing rows from the table
    
    String url = "jdbc:h2:~/test";
    String user = "sa";
    String database_password = "glen";

    try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
        String sql;
        if (selectedCategory.isEmpty()) {
            // Display all books if the category is empty
            sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1";
        } else {
            // Update the SQL query to filter by selected category
            sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1 AND book_category = ?";
        }

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            if (!selectedCategory.isEmpty()) {
                preparedStatement.setString(1, selectedCategory);
            }

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    // Retrieve data from the result set
                    String accNo = resultSet.getString("acc_no");
                    String bookTitle = resultSet.getString("book_title");
                    String bookAuthor = resultSet.getString("book_author");
                    String bookCategory = resultSet.getString("book_category");
                    int bookAvailable = resultSet.getInt("book_available");
                    String bookBorrow = resultSet.getString("book_borrow");
                    String publicationYear = resultSet.getString("publication_year");
                    String bookDescription = resultSet.getString("book_description");
                    byte[] imageData = resultSet.getBytes("book_image");
                    ImageIcon bookImageIcon = new ImageIcon(imageData);

                    // Add a new row to the table model
                    model.addRow(new Object[]{accNo, bookTitle.toUpperCase(), bookAuthor.toUpperCase(), bookCategory.toUpperCase(), bookAvailable, bookBorrow.toUpperCase(), publicationYear, bookDescription, bookImageIcon});
                }
                
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    private static void displayBooksPubYear(String selectedPubYear) {
    DefaultTableModel model = (DefaultTableModel) lms_books_table.getModel();
    model.setRowCount(0); 
    
    String url = "jdbc:h2:~/test";
    String user = "sa";
    String database_password = "glen";

    try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
        String sql;
        if (selectedPubYear.isEmpty()) {
            
            sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1";
        } else {
            
            sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1 AND publication_year = ?";
        }

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            if (!selectedPubYear.isEmpty()) {
                preparedStatement.setString(1, selectedPubYear);
            }

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    
                    String accNo = resultSet.getString("acc_no");
                    String bookTitle = resultSet.getString("book_title");
                    String bookAuthor = resultSet.getString("book_author");
                    String bookCategory = resultSet.getString("book_category");
                    int bookAvailable = resultSet.getInt("book_available");
                    String bookBorrow = resultSet.getString("book_borrow");
                    String publicationYear = resultSet.getString("publication_year");
                    String bookDescription = resultSet.getString("book_description");
                    byte[] imageData = resultSet.getBytes("book_image");
                    ImageIcon bookImageIcon = new ImageIcon(imageData);
                    
                    model.addRow(new Object[]{accNo, bookTitle.toUpperCase(), bookAuthor.toUpperCase(), bookCategory.toUpperCase(), bookAvailable, bookBorrow.toUpperCase(), publicationYear, bookDescription, bookImageIcon});
                    
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
      
    }
    

    private static void displayBooksAvailable(String book_availble) {
    DefaultTableModel model = (DefaultTableModel) lms_books_table.getModel();
    model.setRowCount(0); 
    
    String url = "jdbc:h2:~/test";
    String user = "sa";
    String database_password = "glen";

    try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
        String sql;
        if (book_availble.isEmpty()) {
            
            sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1";
        } else {
            
            sql = "SELECT * FROM LIBRARY_BOOKS WHERE book_status = 1 AND book_available = ?";
        }

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            if (!book_availble.isEmpty()) {
                preparedStatement.setString(1, book_availble);
            }

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    
                    String accNo = resultSet.getString("acc_no");
                    String bookTitle = resultSet.getString("book_title");
                    String bookAuthor = resultSet.getString("book_author");
                    String bookCategory = resultSet.getString("book_category");
                    int bookAvailable = resultSet.getInt("book_available");
                    String bookBorrow = resultSet.getString("book_borrow");
                    String publicationYear = resultSet.getString("publication_year");
                    String bookDescription = resultSet.getString("book_description");
                    
                    byte[] imageData = resultSet.getBytes("book_image");
                    ImageIcon bookImageIcon = new ImageIcon(imageData);
  
                    
                    model.addRow(new Object[]{accNo, bookTitle.toUpperCase(), bookAuthor.toUpperCase(), bookCategory.toUpperCase(), bookAvailable, bookBorrow.toUpperCase(), publicationYear, bookDescription, bookImageIcon});
                }
            }
        }
        
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
     public static void displayAnnouncement(){
    String url = "jdbc:h2:~/test";
        String user = "sa";
        String database_password = "glen";

        try (Connection connection = DriverManager.getConnection(url, user, database_password)) {
            String sql = "SELECT * FROM LIBRARY_ANNOUNCEMENT";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String announcement_lib = resultSet.getString("announcement");
                        lib_announcement.setText(announcement_lib);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    
    }
}